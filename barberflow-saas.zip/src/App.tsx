import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import LandingPage from './pages/LandingPage';
import SalonRegister from './pages/SalonRegister';
import SalonLogin from './pages/SalonLogin';
import AdminLogin from './pages/AdminLogin';
import AdminPanel from './pages/AdminPanel';
import SalonPanel from './pages/SalonPanel';
import BookingPage from './pages/BookingPage';
import MyBookings from './pages/MyBookings';
import BottomNav from './components/BottomNav';
import { motion, AnimatePresence } from 'motion/react';

import { requestNotificationPermission } from './lib/notifications';
import { auth } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

function RootRedirect() {
  const lastSlug = localStorage.getItem('last_salon_slug');
  if (lastSlug) {
    return <Navigate to={`/book/${lastSlug}`} replace />;
  }
  return <LandingPage />;
}

export default function App() {
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        requestNotificationPermission();
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-zinc-100 selection:text-zinc-950">
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<RootRedirect />} />
            <Route path="/register" element={<SalonRegister />} />
            <Route path="/login" element={<SalonLogin />} />
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin/*" element={<AdminPanel />} />
            <Route path="/salon/*" element={<SalonPanel />} />
            <Route path="/book/:slug" element={<BookingPage />} />
            <Route path="/my-bookings" element={<MyBookings />} />
          </Routes>
        </AnimatePresence>
        <BottomNav />
      </div>
    </BrowserRouter>
  );
}
