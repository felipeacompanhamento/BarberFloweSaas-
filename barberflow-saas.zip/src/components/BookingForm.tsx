import { useState, useEffect } from 'react';
import { collection, query, where, getDocs, addDoc, Timestamp, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors, Calendar, Clock, User, Phone, CheckCircle2, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { format, addMinutes, startOfDay, endOfDay, isSameDay, isAfter, parseISO, setHours, setMinutes } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn, formatCurrency } from '../lib/utils';

interface Barber {
  id: string;
  name: string;
  photoUrl?: string;
  active: boolean;
}

interface Service {
  id: string;
  name: string;
  price: number;
  durationMinutes: number;
  barberId: string;
}

interface Availability {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

export default function BookingForm({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [barbers, setBarbers] = useState<Barber[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);

  useEffect(() => {
    const fetchBarbers = async () => {
      const q = query(collection(db, 'barbers'), where('active', '==', true));
      const snapshot = await getDocs(q);
      setBarbers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Barber)));
    };
    fetchBarbers();
  }, []);

  useEffect(() => {
    if (selectedBarber) {
      const fetchServices = async () => {
        const q = query(collection(db, 'services'), where('barberId', '==', selectedBarber.id));
        const snapshot = await getDocs(q);
        setServices(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service)));
      };
      fetchServices();
    }
  }, [selectedBarber]);

  useEffect(() => {
    if (selectedBarber && selectedService && selectedDate) {
      fetchAvailableSlots();
    }
  }, [selectedBarber, selectedService, selectedDate]);

  const fetchAvailableSlots = async () => {
    if (!selectedBarber || !selectedService) return;
    setLoading(true);
    
    // 1. Get availability for the day of week
    const dayOfWeek = selectedDate.getDay();
    const qAvail = query(
      collection(db, 'availability'), 
      where('barberId', '==', selectedBarber.id),
      where('dayOfWeek', '==', dayOfWeek)
    );
    const availSnapshot = await getDocs(qAvail);
    const availability = availSnapshot.docs.map(doc => doc.data() as Availability)[0];

    if (!availability) {
      setAvailableSlots([]);
      setLoading(false);
      return;
    }

    // 2. Get existing appointments for the day
    const start = startOfDay(selectedDate);
    const end = endOfDay(selectedDate);
    const qAppts = query(
      collection(db, 'appointments'),
      where('barberId', '==', selectedBarber.id),
      where('startAt', '>=', Timestamp.fromDate(start)),
      where('startAt', '<=', Timestamp.fromDate(end)),
      where('status', '==', 'scheduled')
    );
    const apptsSnapshot = await getDocs(qAppts);
    const appointments = apptsSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        start: data.startAt.toDate(),
        end: data.endAt.toDate()
      };
    });

    // 3. Generate slots
    const slots: string[] = [];
    const [startH, startM] = availability.startTime.split(':').map(Number);
    const [endH, endM] = availability.endTime.split(':').map(Number);
    
    let current = setMinutes(setHours(startOfDay(selectedDate), startH), startM);
    const endTime = setMinutes(setHours(startOfDay(selectedDate), endH), endM);

    while (isAfter(endTime, current)) {
      const slotEnd = addMinutes(current, selectedService.durationMinutes);
      
      // Check if slot overlaps with any appointment
      const isOccupied = appointments.some(appt => {
        return (current >= appt.start && current < appt.end) || 
               (slotEnd > appt.start && slotEnd <= appt.end) ||
               (current <= appt.start && slotEnd >= appt.end);
      });

      // Check if slot is in the past
      const isPast = !isAfter(current, new Date());

      if (!isOccupied && !isPast && isAfter(endTime, slotEnd)) {
        slots.push(format(current, 'HH:mm'));
      }
      
      current = addMinutes(current, 30); // 30 min increments
    }

    setAvailableSlots(slots);
    setLoading(false);
  };

  const handleBooking = async () => {
    if (!selectedBarber || !selectedService || !selectedTime || !clientName || !clientPhone) return;
    setLoading(true);

    const [h, m] = selectedTime.split(':').map(Number);
    const startAt = setMinutes(setHours(startOfDay(selectedDate), h), m);
    const endAt = addMinutes(startAt, selectedService.durationMinutes);

    try {
      await addDoc(collection(db, 'appointments'), {
        clientName,
        clientPhone: clientPhone.replace(/\D/g, ''),
        barberId: selectedBarber.id,
        serviceId: selectedService.id,
        startAt: Timestamp.fromDate(startAt),
        endAt: Timestamp.fromDate(endAt),
        status: 'scheduled',
        createdAt: Timestamp.now()
      });
      setStep(5); // Success step
    } catch (error) {
      console.error('Booking error:', error);
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  return (
    <div className="max-w-xl mx-auto p-4">
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
                <User size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold">Escolha seu Barbeiro</h2>
                <p className="text-zinc-400 text-sm">Selecione o profissional de sua preferência</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {barbers.map(barber => (
                <button
                  key={barber.id}
                  onClick={() => { setSelectedBarber(barber); nextStep(); }}
                  className={cn(
                    "flex items-center gap-4 p-4 rounded-2xl border transition-all active:scale-95",
                    selectedBarber?.id === barber.id 
                      ? "bg-zinc-100 border-zinc-100 text-zinc-950" 
                      : "bg-zinc-900 border-zinc-800 text-zinc-100 hover:border-zinc-700"
                  )}
                >
                  <div className="w-14 h-14 bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden">
                    {barber.photoUrl ? (
                      <img src={barber.photoUrl} alt={barber.name} className="w-full h-full object-cover" />
                    ) : (
                      <User size={24} className="text-zinc-500" />
                    )}
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{barber.name}</p>
                    <p className="text-sm opacity-60">Disponível hoje</p>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <button onClick={prevStep} className="flex items-center gap-2 text-zinc-400 hover:text-zinc-100 transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
                <Scissors size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold">Escolha o Serviço</h2>
                <p className="text-zinc-400 text-sm">O que vamos fazer hoje?</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {services.map(service => (
                <button
                  key={service.id}
                  onClick={() => { setSelectedService(service); nextStep(); }}
                  className={cn(
                    "flex items-center justify-between p-5 rounded-2xl border transition-all active:scale-95",
                    selectedService?.id === service.id 
                      ? "bg-zinc-100 border-zinc-100 text-zinc-950" 
                      : "bg-zinc-900 border-zinc-800 text-zinc-100 hover:border-zinc-700"
                  )}
                >
                  <div className="text-left">
                    <p className="font-bold text-lg">{service.name}</p>
                    <p className="text-sm opacity-60 flex items-center gap-1">
                      <Clock size={14} /> {service.durationMinutes} min
                    </p>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(service.price)}</p>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <button onClick={prevStep} className="flex items-center gap-2 text-zinc-400 hover:text-zinc-100 transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
                <Calendar size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold">Data e Hora</h2>
                <p className="text-zinc-400 text-sm">Selecione o melhor momento</p>
              </div>
            </div>

            <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar">
              {[0, 1, 2, 3, 4, 5, 6].map(i => {
                const date = new Date();
                date.setDate(date.getDate() + i);
                const isSelected = isSameDay(date, selectedDate);
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedDate(date)}
                    className={cn(
                      "flex-shrink-0 w-16 h-20 rounded-2xl flex flex-col items-center justify-center gap-1 border transition-all",
                      isSelected 
                        ? "bg-zinc-100 border-zinc-100 text-zinc-950" 
                        : "bg-zinc-900 border-zinc-800 text-zinc-100"
                    )}
                  >
                    <span className="text-[10px] uppercase font-bold opacity-60">
                      {format(date, 'EEE', { locale: ptBR })}
                    </span>
                    <span className="text-xl font-bold">{format(date, 'dd')}</span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-3 gap-3">
              {loading ? (
                <div className="col-span-3 flex justify-center py-8">
                  <Loader2 className="animate-spin text-zinc-400" />
                </div>
              ) : availableSlots.length > 0 ? (
                availableSlots.map(time => (
                  <button
                    key={time}
                    onClick={() => { setSelectedTime(time); nextStep(); }}
                    className={cn(
                      "py-3 rounded-xl border font-bold transition-all active:scale-95",
                      selectedTime === time 
                        ? "bg-zinc-100 border-zinc-100 text-zinc-950" 
                        : "bg-zinc-900 border-zinc-800 text-zinc-100"
                    )}
                  >
                    {time}
                  </button>
                ))
              ) : (
                <div className="col-span-3 text-center py-8 text-zinc-500">
                  Nenhum horário disponível para esta data.
                </div>
              )}
            </div>
          </motion.div>
        )}

        {step === 4 && (
          <motion.div
            key="step4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <button onClick={prevStep} className="flex items-center gap-2 text-zinc-400 hover:text-zinc-100 transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
                <CheckCircle2 size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold">Confirmação</h2>
                <p className="text-zinc-400 text-sm">Quase lá! Só precisamos de seus dados</p>
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-500">Barbeiro</span>
                <span className="font-bold">{selectedBarber?.name}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-500">Serviço</span>
                <span className="font-bold">{selectedService?.name}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-500">Data e Hora</span>
                <span className="font-bold">
                  {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })} às {selectedTime}
                </span>
              </div>
              <div className="pt-4 border-t border-zinc-800 flex justify-between items-center">
                <span className="text-zinc-500">Total</span>
                <span className="text-xl font-bold">{formatCurrency(selectedService?.price || 0)}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Seu Nome</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={e => setClientName(e.target.value)}
                  placeholder="Ex: João Silva"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Seu Telefone</label>
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={e => setClientPhone(e.target.value)}
                  placeholder="Ex: 11999999999"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
            </div>

            <button
              disabled={!clientName || !clientPhone || loading}
              onClick={handleBooking}
              className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 transition-all active:scale-95"
            >
              {loading ? <Loader2 className="animate-spin" /> : "Confirmar Agendamento"}
            </button>
          </motion.div>
        )}

        {step === 5 && (
          <motion.div
            key="step5"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-center space-y-6 py-12"
          >
            <div className="w-24 h-24 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={48} />
            </div>
            <h2 className="text-3xl font-bold">Agendado com Sucesso!</h2>
            <p className="text-zinc-400 max-w-xs mx-auto">
              Seu horário foi reservado. Te esperamos em breve na barbearia!
            </p>
            <button
              onClick={onComplete}
              className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold transition-all active:scale-95"
            >
              Voltar ao Início
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
