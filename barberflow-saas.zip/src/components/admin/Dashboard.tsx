import { useState, useEffect } from 'react';
import { collection, query, getDocs, Timestamp, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion } from 'motion/react';
import { TrendingUp, Users, Scissors, DollarSign, Loader2 } from 'lucide-react';
import { formatCurrency, cn } from '../../lib/utils';
import { startOfMonth, endOfMonth } from 'date-fns';

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalAppointments: 0,
    totalRevenue: 0,
    activeBarbers: 0,
    totalServices: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const now = new Date();
        const start = startOfMonth(now);
        const end = endOfMonth(now);

        const qAppts = query(
          collection(db, 'appointments'),
          where('startAt', '>=', Timestamp.fromDate(start)),
          where('startAt', '<=', Timestamp.fromDate(end))
        );
        const apptsSnapshot = await getDocs(qAppts);
        const appts = apptsSnapshot.docs.map(doc => doc.data());

        const qBarbers = query(collection(db, 'barbers'), where('active', '==', true));
        const barbersSnapshot = await getDocs(qBarbers);

        const qServices = query(collection(db, 'services'));
        const servicesSnapshot = await getDocs(qServices);
        const services = servicesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        let revenue = 0;
        appts.forEach((appt: any) => {
          if (appt.status === 'completed') {
            const service = services.find((s: any) => s.id === appt.serviceId) as any;
            if (service) revenue += service.price;
          }
        });

        setStats({
          totalAppointments: appts.length,
          totalRevenue: revenue,
          activeBarbers: barbersSnapshot.size,
          totalServices: servicesSnapshot.size
        });
      } catch (error) {
        console.error('Stats error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="animate-spin text-zinc-400" />
      </div>
    );
  }

  const cards = [
    { title: 'Agendamentos (Mês)', value: stats.totalAppointments, icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { title: 'Faturamento Estimado', value: formatCurrency(stats.totalRevenue), icon: DollarSign, color: 'text-green-500', bg: 'bg-green-500/10' },
    { title: 'Barbeiros Ativos', value: stats.activeBarbers, icon: Users, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { title: 'Serviços Oferecidos', value: stats.totalServices, icon: Scissors, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", card.bg, card.color)}>
                <card.icon size={24} />
              </div>
            </div>
            <p className="text-zinc-400 text-sm font-medium">{card.title}</p>
            <h3 className="text-2xl font-bold mt-1">{card.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl">
        <h3 className="text-xl font-bold mb-6">Visão Geral</h3>
        <p className="text-zinc-400">
          Bem-vindo ao seu painel administrativo. Aqui você pode acompanhar o desempenho da sua barbearia em tempo real.
        </p>
      </div>
    </div>
  );
}

