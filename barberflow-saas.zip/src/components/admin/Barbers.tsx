import { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { User, Plus, Trash2, Edit2, Check, X, Loader2 } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function Barbers() {
  const [loading, setLoading] = useState(true);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhoto, setNewPhoto] = useState('');

  useEffect(() => {
    const fetchBarbers = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'barbers'));
        setBarbers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error('Barbers error:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchBarbers();
  }, []);

  const addBarber = async () => {
    if (!newName) return;
    setLoading(true);
    try {
      const docRef = await addDoc(collection(db, 'barbers'), {
        name: newName,
        photoUrl: newPhoto || null,
        active: true
      });
      setBarbers(prev => [...prev, { id: docRef.id, name: newName, photoUrl: newPhoto || null, active: true }]);
      setNewName('');
      setNewPhoto('');
      setIsAdding(false);
    } catch (error) {
      console.error('Add barber error:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (id: string, current: boolean) => {
    try {
      await updateDoc(doc(db, 'barbers', id), { active: !current });
      setBarbers(prev => prev.map(b => b.id === id ? { ...b, active: !current } : b));
    } catch (error) {
      console.error('Toggle active error:', error);
    }
  };

  const deleteBarber = async (id: string) => {
    if (!confirm('Tem certeza? Isso pode afetar serviços e agendamentos.')) return;
    try {
      await deleteDoc(doc(db, 'barbers', id));
      setBarbers(prev => prev.filter(b => b.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Barbeiros</h2>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-zinc-200 transition-all active:scale-95"
        >
          <Plus size={20} /> Novo Barbeiro
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl space-y-4 overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Nome do Barbeiro</label>
                <input
                  type="text"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">URL da Foto (Opcional)</label>
                <input
                  type="text"
                  value={newPhoto}
                  onChange={e => setNewPhoto(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setIsAdding(false)} className="px-6 py-3 text-zinc-400 font-bold">Cancelar</button>
              <button onClick={addBarber} className="bg-zinc-100 text-zinc-950 px-8 py-3 rounded-2xl font-bold">Salvar</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <Loader2 className="animate-spin text-zinc-400" />
          </div>
        ) : barbers.map(barber => (
          <motion.div
            layout
            key={barber.id}
            className={cn(
              "bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col items-center text-center gap-4",
              !barber.active && "opacity-50 grayscale"
            )}
          >
            <div className="w-20 h-20 bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden border-2 border-zinc-800">
              {barber.photoUrl ? (
                <img src={barber.photoUrl} alt={barber.name} className="w-full h-full object-cover" />
              ) : (
                <User size={32} className="text-zinc-600" />
              )}
            </div>
            <div>
              <h3 className="text-xl font-bold">{barber.name}</h3>
              <p className="text-sm text-zinc-500">{barber.active ? 'Ativo' : 'Inativo'}</p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => toggleActive(barber.id, barber.active)}
                className={cn(
                  "p-3 rounded-xl transition-colors",
                  barber.active ? "bg-green-500/10 text-green-500 hover:bg-green-500/20" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                )}
                title={barber.active ? 'Desativar' : 'Ativar'}
              >
                <Check size={20} />
              </button>
              <button
                onClick={() => deleteBarber(barber.id)}
                className="p-3 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500/20 transition-colors"
                title="Excluir"
              >
                <Trash2 size={20} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
