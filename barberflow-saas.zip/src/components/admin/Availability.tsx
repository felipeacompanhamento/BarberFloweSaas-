import { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, updateDoc, doc, deleteDoc, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Plus, Trash2, Loader2, User, Calendar } from 'lucide-react';
import { cn } from '../../lib/utils';

const DAYS = [
  { id: 0, name: 'Domingo' },
  { id: 1, name: 'Segunda' },
  { id: 2, name: 'Terça' },
  { id: 3, name: 'Quarta' },
  { id: 4, name: 'Quinta' },
  { id: 5, name: 'Sexta' },
  { id: 6, name: 'Sábado' },
];

export default function Availability() {
  const [loading, setLoading] = useState(true);
  const [availability, setAvailability] = useState<any[]>([]);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newBarberId, setNewBarberId] = useState('');
  const [newDay, setNewDay] = useState('1');
  const [newStart, setNewStart] = useState('09:00');
  const [newEnd, setNewEnd] = useState('18:00');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const barbersSnapshot = await getDocs(collection(db, 'barbers'));
        const barbersData = barbersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setBarbers(barbersData);
        if (barbersData.length > 0) setNewBarberId(barbersData[0].id);

        const availSnapshot = await getDocs(collection(db, 'availability'));
        setAvailability(availSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error('Data error:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const addAvailability = async () => {
    if (!newBarberId || !newDay || !newStart || !newEnd) return;
    setLoading(true);
    try {
      const docRef = await addDoc(collection(db, 'availability'), {
        barberId: newBarberId,
        dayOfWeek: Number(newDay),
        startTime: newStart,
        endTime: newEnd
      });
      setAvailability(prev => [...prev, { id: docRef.id, barberId: newBarberId, dayOfWeek: Number(newDay), startTime: newStart, endTime: newEnd }]);
      setIsAdding(false);
    } catch (error) {
      console.error('Add availability error:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteAvailability = async (id: string) => {
    if (!confirm('Tem certeza?')) return;
    try {
      await deleteDoc(doc(db, 'availability', id));
      setAvailability(prev => prev.filter(a => a.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Horários de Funcionamento</h2>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-zinc-200 transition-all active:scale-95"
        >
          <Plus size={20} /> Novo Horário
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl space-y-4 overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Barbeiro</label>
                <select
                  value={newBarberId}
                  onChange={e => setNewBarberId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                >
                  {barbers.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Dia da Semana</label>
                <select
                  value={newDay}
                  onChange={e => setNewDay(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                >
                  {DAYS.map(d => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Hora Início</label>
                <input
                  type="time"
                  value={newStart}
                  onChange={e => setNewStart(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Hora Fim</label>
                <input
                  type="time"
                  value={newEnd}
                  onChange={e => setNewEnd(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setIsAdding(false)} className="px-6 py-3 text-zinc-400 font-bold">Cancelar</button>
              <button onClick={addAvailability} className="bg-zinc-100 text-zinc-950 px-8 py-3 rounded-2xl font-bold">Salvar</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <Loader2 className="animate-spin text-zinc-400" />
          </div>
        ) : availability.sort((a,b) => a.dayOfWeek - b.dayOfWeek).map(avail => {
          const barber = barbers.find(b => b.id === avail.barberId);
          const dayName = DAYS.find(d => d.id === avail.dayOfWeek)?.name;
          
          return (
            <motion.div
              layout
              key={avail.id}
              className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col gap-4"
            >
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 bg-zinc-800 rounded-2xl flex items-center justify-center text-zinc-400">
                  <Calendar size={24} />
                </div>
                <button
                  onClick={() => deleteAvailability(avail.id)}
                  className="p-3 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500/20 transition-colors"
                  title="Excluir"
                >
                  <Trash2 size={20} />
                </button>
              </div>
              <div>
                <h3 className="text-xl font-bold">{dayName}</h3>
                <p className="text-sm text-zinc-500 flex items-center gap-1">
                  Barbeiro: <span className="text-zinc-300 font-medium">{barber?.name || 'Desconhecido'}</span>
                </p>
              </div>
              <div className="flex items-center gap-4 pt-2 border-t border-zinc-800">
                <div className="flex items-center gap-2 text-lg font-bold text-zinc-100">
                  <Clock size={20} className="text-zinc-500" />
                  {avail.startTime} - {avail.endTime}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
