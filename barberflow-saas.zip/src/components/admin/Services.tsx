import { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, updateDoc, doc, deleteDoc, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors, Plus, Trash2, Edit2, Check, X, Loader2, Clock, DollarSign } from 'lucide-react';
import { cn, formatCurrency } from '../../lib/utils';

export default function Services() {
  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<any[]>([]);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newDuration, setNewDuration] = useState('30');
  const [newBarberId, setNewBarberId] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const barbersSnapshot = await getDocs(collection(db, 'barbers'));
        const barbersData = barbersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setBarbers(barbersData);
        if (barbersData.length > 0) setNewBarberId(barbersData[0].id);

        const servicesSnapshot = await getDocs(collection(db, 'services'));
        setServices(servicesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error('Data error:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const addService = async () => {
    if (!newName || !newPrice || !newBarberId) return;
    setLoading(true);
    try {
      const docRef = await addDoc(collection(db, 'services'), {
        name: newName,
        price: Number(newPrice),
        durationMinutes: Number(newDuration),
        barberId: newBarberId
      });
      setServices(prev => [...prev, { id: docRef.id, name: newName, price: Number(newPrice), durationMinutes: Number(newDuration), barberId: newBarberId }]);
      setNewName('');
      setNewPrice('');
      setNewDuration('30');
      setIsAdding(false);
    } catch (error) {
      console.error('Add service error:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteService = async (id: string) => {
    if (!confirm('Tem certeza?')) return;
    try {
      await deleteDoc(doc(db, 'services', id));
      setServices(prev => prev.filter(s => s.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Serviços</h2>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-zinc-200 transition-all active:scale-95"
        >
          <Plus size={20} /> Novo Serviço
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl space-y-4 overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Nome do Serviço</label>
                <input
                  type="text"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Preço (R$)</label>
                <input
                  type="number"
                  value={newPrice}
                  onChange={e => setNewPrice(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Duração (Minutos)</label>
                <select
                  value={newDuration}
                  onChange={e => setNewDuration(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                >
                  <option value="15">15 min</option>
                  <option value="30">30 min</option>
                  <option value="45">45 min</option>
                  <option value="60">60 min</option>
                  <option value="90">90 min</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Barbeiro Responsável</label>
                <select
                  value={newBarberId}
                  onChange={e => setNewBarberId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                >
                  {barbers.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setIsAdding(false)} className="px-6 py-3 text-zinc-400 font-bold">Cancelar</button>
              <button onClick={addService} className="bg-zinc-100 text-zinc-950 px-8 py-3 rounded-2xl font-bold">Salvar</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <Loader2 className="animate-spin text-zinc-400" />
          </div>
        ) : services.map(service => {
          const barber = barbers.find(b => b.id === service.barberId);
          return (
            <motion.div
              layout
              key={service.id}
              className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col gap-4"
            >
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 bg-zinc-800 rounded-2xl flex items-center justify-center text-zinc-400">
                  <Scissors size={24} />
                </div>
                <button
                  onClick={() => deleteService(service.id)}
                  className="p-3 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500/20 transition-colors"
                  title="Excluir"
                >
                  <Trash2 size={20} />
                </button>
              </div>
              <div>
                <h3 className="text-xl font-bold">{service.name}</h3>
                <p className="text-sm text-zinc-500 flex items-center gap-1">
                  Barbeiro: <span className="text-zinc-300 font-medium">{barber?.name || 'Desconhecido'}</span>
                </p>
              </div>
              <div className="flex items-center gap-4 pt-2 border-t border-zinc-800">
                <div className="flex items-center gap-2 text-sm text-zinc-400">
                  <Clock size={16} /> {service.durationMinutes} min
                </div>
                <div className="flex items-center gap-2 text-lg font-bold text-zinc-100 ml-auto">
                  {formatCurrency(service.price)}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
