import { useState, useEffect } from 'react';
import { collection, query, getDocs, Timestamp, where, orderBy, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, User, Phone, CheckCircle2, XCircle, Trash2, Loader2, Filter, Scissors } from 'lucide-react';
import { format, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn, formatCurrency } from '../../lib/utils';

export default function Agenda() {
  const [loading, setLoading] = useState(true);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [filterDate, setFilterDate] = useState<Date>(new Date());
  const [barbers, setBarbers] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const barbersSnapshot = await getDocs(collection(db, 'barbers'));
        setBarbers(barbersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        const servicesSnapshot = await getDocs(collection(db, 'services'));
        setServices(servicesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error('Data error:', error);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchAppointments = async () => {
      setLoading(true);
      try {
        const start = startOfDay(filterDate);
        const end = endOfDay(filterDate);
        const q = query(
          collection(db, 'appointments'),
          where('startAt', '>=', Timestamp.fromDate(start)),
          where('startAt', '<=', Timestamp.fromDate(end)),
          orderBy('startAt', 'asc')
        );
        const snapshot = await getDocs(q);
        setAppointments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error('Appointments error:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchAppointments();
  }, [filterDate]);

  const updateStatus = async (id: string, status: string) => {
    try {
      await updateDoc(doc(db, 'appointments', id), { status });
      setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    } catch (error) {
      console.error('Update status error:', error);
    }
  };

  const deleteAppointment = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este agendamento?')) return;
    try {
      await deleteDoc(doc(db, 'appointments', id));
      setAppointments(prev => prev.filter(a => a.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Agenda Diária</h2>
        <div className="flex items-center gap-3 bg-zinc-900 border border-zinc-800 p-2 rounded-2xl">
          <Calendar size={20} className="text-zinc-500 ml-2" />
          <input
            type="date"
            value={format(filterDate, 'yyyy-MM-dd')}
            onChange={e => setFilterDate(new Date(e.target.value + 'T00:00:00'))}
            className="bg-transparent border-none focus:ring-0 text-zinc-100 p-2"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin text-zinc-400" />
          </div>
        ) : appointments.length > 0 ? (
          appointments.map(appt => {
            const barber = barbers.find(b => b.id === appt.barberId);
            const service = services.find(s => s.id === appt.serviceId);
            
            return (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={appt.id}
                className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-800 rounded-2xl flex items-center justify-center text-zinc-400">
                    <Clock size={24} />
                  </div>
                  <div>
                    <p className="text-xl font-bold">{format(appt.startAt.toDate(), 'HH:mm')}</p>
                    <p className="text-sm text-zinc-400">{service?.name || 'Serviço'}</p>
                  </div>
                </div>

                <div className="flex-1 space-y-1">
                  <p className="font-bold flex items-center gap-2">
                    <User size={16} className="text-zinc-500" /> {appt.clientName}
                  </p>
                  <p className="text-sm text-zinc-400 flex items-center gap-2">
                    <Phone size={14} className="text-zinc-500" /> {appt.clientPhone}
                  </p>
                  <p className="text-sm text-zinc-400 flex items-center gap-2">
                    <Scissors size={14} className="text-zinc-500" /> {barber?.name || 'Barbeiro'}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  {appt.status === 'scheduled' && (
                    <>
                      <button
                        onClick={() => updateStatus(appt.id, 'completed')}
                        className="p-3 bg-green-500/10 text-green-500 rounded-2xl hover:bg-green-500/20 transition-colors"
                        title="Concluir"
                      >
                        <CheckCircle2 size={20} />
                      </button>
                      <button
                        onClick={() => updateStatus(appt.id, 'cancelled')}
                        className="p-3 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500/20 transition-colors"
                        title="Cancelar"
                      >
                        <XCircle size={20} />
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => deleteAppointment(appt.id)}
                    className="p-3 bg-zinc-800 text-zinc-400 rounded-2xl hover:bg-zinc-700 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 size={20} />
                  </button>
                  <span className={cn(
                    "px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider",
                    appt.status === 'scheduled' ? "bg-blue-500/10 text-blue-500" :
                    appt.status === 'completed' ? "bg-green-500/10 text-green-500" :
                    "bg-red-500/10 text-red-500"
                  )}>
                    {appt.status === 'scheduled' ? 'Agendado' : 
                     appt.status === 'completed' ? 'Concluído' : 'Cancelado'}
                  </span>
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="text-center py-24 bg-zinc-900/50 border border-zinc-800 border-dashed rounded-3xl">
            <Calendar size={48} className="mx-auto mb-4 text-zinc-700" />
            <p className="text-zinc-500 font-medium">Nenhum agendamento para este dia.</p>
          </div>
        )}
      </div>
    </div>
  );
}
