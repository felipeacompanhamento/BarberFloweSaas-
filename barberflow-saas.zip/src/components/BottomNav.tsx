import { useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Calendar, User } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const [isHidden, setIsHidden] = useState(document.body.classList.contains('hide-bottom-nav'));

  useEffect(() => {
    const observer = new MutationObserver(() => {
      setIsHidden(document.body.classList.contains('hide-bottom-nav'));
    });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const isSalonPage = location.pathname.startsWith('/book') || location.pathname === '/my-bookings';
  const isLoggedIn = localStorage.getItem('barber_client_phone');
  
  if (!isSalonPage || !isLoggedIn || isHidden) return null;

  const lastSlug = localStorage.getItem('last_salon_slug');
  const agendarPath = location.pathname.startsWith('/book') 
    ? location.pathname 
    : (lastSlug ? `/book/${lastSlug}` : '/');

  const navItems = [
    {
      label: 'Agendar',
      icon: Calendar,
      path: agendarPath, 
      active: location.pathname.startsWith('/book')
    },
    {
      label: 'Meus Agendamentos',
      icon: User,
      path: '/my-bookings',
      active: location.pathname === '/my-bookings'
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[100] px-6 pb-6 pointer-events-none">
      <div className="max-w-md mx-auto bg-zinc-900/90 backdrop-blur-2xl border border-zinc-800/50 rounded-[32px] p-2 flex items-center justify-around shadow-[0_20px_50px_rgba(0,0,0,0.5)] pointer-events-auto">
        {navItems.map((item) => (
          <button
            key={item.label}
            onClick={() => navigate(item.path)}
            className={cn(
              "flex flex-col items-center gap-1.5 px-6 py-3 rounded-2xl transition-all duration-300 relative",
              item.active ? "text-zinc-950" : "text-zinc-500 hover:text-zinc-300"
            )}
          >
            {item.active && (
              <motion.div
                layoutId="nav-active"
                className="absolute inset-0 bg-zinc-100 rounded-2xl -z-10"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <item.icon size={20} strokeWidth={item.active ? 2.5 : 2} />
            <span className="text-[9px] font-black uppercase tracking-[0.1em]">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
