import { useState } from 'react';
import { collection, query, where, getDocs, orderBy, limit, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Calendar, Clock, Scissors, User, Phone, ChevronLeft, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn, formatCurrency } from '../lib/utils';

interface Appointment {
  id: string;
  clientName: string;
  clientPhone: string;
  barberId: string;
  serviceId: string;
  startAt: Timestamp;
  status: string;
}

export default function ClientAppointments({ onBack }: { onBack: () => void }) {
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [searched, setSearched] = useState(false);

  const handleSearch = async () => {
    if (!phone) return;
    setLoading(true);
    setSearched(true);
    
    const cleanPhone = phone.replace(/\D/g, '');
    
    try {
      const q = query(
        collection(db, 'appointments'),
        where('clientPhone', '==', cleanPhone),
        orderBy('startAt', 'desc'),
        limit(10)
      );
      
      const snapshot = await getDocs(q);
      const appts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      // Fetch barber and service names
      const enrichedAppts = await Promise.all(appts.map(async (appt: any) => {
        const barberSnap = await getDocs(query(collection(db, 'barbers'), where('__name__', '==', appt.barberId)));
        const serviceSnap = await getDocs(query(collection(db, 'services'), where('__name__', '==', appt.serviceId)));
        
        return {
          ...appt,
          barberName: barberSnap.docs[0]?.data()?.name || 'Barbeiro',
          serviceName: serviceSnap.docs[0]?.data()?.name || 'Serviço',
          price: serviceSnap.docs[0]?.data()?.price || 0
        };
      }));
      
      setAppointments(enrichedAppts);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4 space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-zinc-100 transition-colors">
        <ChevronLeft size={20} /> Voltar
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
          <Search size={20} />
        </div>
        <div>
          <h2 className="text-xl font-bold">Meus Agendamentos</h2>
          <p className="text-zinc-400 text-sm">Consulte seus horários pelo telefone</p>
        </div>
      </div>

      <div className="flex gap-2">
        <input
          type="tel"
          value={phone}
          onChange={e => setPhone(e.target.value)}
          placeholder="Seu telefone (DDD + número)"
          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
        />
        <button
          onClick={handleSearch}
          disabled={loading || !phone}
          className="bg-zinc-100 text-zinc-950 px-6 rounded-2xl font-bold disabled:opacity-50 transition-all active:scale-95"
        >
          {loading ? <Loader2 className="animate-spin" /> : "Buscar"}
        </button>
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin text-zinc-400" />
          </div>
        ) : appointments.length > 0 ? (
          appointments.map(appt => (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={appt.id}
              className="bg-zinc-900 border border-zinc-800 p-5 rounded-3xl space-y-4"
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-lg">{appt.serviceName}</p>
                  <p className="text-sm text-zinc-400 flex items-center gap-1">
                    <User size={14} /> {appt.barberName}
                  </p>
                </div>
                <span className={cn(
                  "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                  appt.status === 'scheduled' ? "bg-blue-500/10 text-blue-500" :
                  appt.status === 'completed' ? "bg-green-500/10 text-green-500" :
                  "bg-red-500/10 text-red-500"
                )}>
                  {appt.status === 'scheduled' ? 'Agendado' : 
                   appt.status === 'completed' ? 'Concluído' : 'Cancelado'}
                </span>
              </div>
              
              <div className="flex items-center gap-4 pt-4 border-t border-zinc-800">
                <div className="flex items-center gap-2 text-sm text-zinc-300">
                  <Calendar size={16} className="text-zinc-500" />
                  {format(appt.startAt.toDate(), "dd/MM/yyyy")}
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-300">
                  <Clock size={16} className="text-zinc-500" />
                  {format(appt.startAt.toDate(), "HH:mm")}
                </div>
                <div className="ml-auto font-bold">
                  {formatCurrency(appt.price)}
                </div>
              </div>
            </motion.div>
          ))
        ) : searched && (
          <div className="text-center py-12 text-zinc-500">
            Nenhum agendamento encontrado para este número.
          </div>
        )}
      </div>
    </div>
  );
}
