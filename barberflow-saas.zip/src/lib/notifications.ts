import { getToken, onMessage } from 'firebase/messaging';
import { messaging, auth, db } from './firebase';
import { doc, setDoc, collection, query, where, getDocs } from 'firebase/firestore';

export async function requestNotificationPermission(identifier?: string) {
  if (!messaging) return;

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      const token = await getToken(messaging, {
        vapidKey: import.meta.env.VITE_VAPID_KEY
      });

      if (token && identifier) {
        // Store token in Firestore associated with the identifier (phone or uid)
        await setDoc(doc(db, 'fcm_tokens', identifier.replace(/\D/g, '')), {
          token,
          updatedAt: new Date(),
          identifier: identifier.replace(/\D/g, '')
        });
        return token;
      }
    }
  } catch (error) {
    console.error('Error requesting notification permission:', error);
  }
  return null;
}

export function onMessageListener() {
  if (!messaging) return;
  
  return new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      resolve(payload);
    });
  });
}
