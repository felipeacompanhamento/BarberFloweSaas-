import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Scissors, CheckCircle2, Zap, Smartphone, DollarSign, ArrowRight, Calendar } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function LandingPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    setIsLoggedIn(!!localStorage.getItem('barber_client_phone'));
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 pb-32">
      {/* Navbar */}
      <nav className="p-6 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <img src="/logo.svg" alt="BarberFlow Logo" className="w-10 h-10 rounded-xl" />
          <h1 className="text-xl font-bold tracking-tight">BarberFlow SaaS</h1>
        </div>
        <div className="flex items-center gap-6">
          {isLoggedIn && (
            <Link to="/my-bookings" className="hidden sm:flex items-center gap-2 text-sm font-bold text-zinc-100 hover:text-zinc-400 transition-colors">
              <Calendar size={16} /> Meus Agendamentos
            </Link>
          )}
          <Link to="/login" className="text-sm font-medium text-zinc-400 hover:text-zinc-100 transition-colors">Entrar</Link>
          <Link to="/register" className="bg-zinc-100 text-zinc-950 px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-zinc-200 transition-all active:scale-95">Criar meu Salão</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="px-6 py-20 text-center max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <span className="px-4 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-400 uppercase tracking-widest">7 dias grátis • Sem cartão</span>
          <h2 className="text-5xl md:text-7xl font-bold tracking-tighter leading-tight">
            A agenda da sua barbearia no <span className="text-zinc-500">piloto automático.</span>
          </h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Aumente seu faturamento e organize sua agenda com o sistema mais simples e eficiente do mercado.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link to="/register" className="w-full sm:w-auto bg-zinc-100 text-zinc-950 px-10 py-5 rounded-2xl text-lg font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95">
              Começar agora <ArrowRight size={20} />
            </Link>
            <Link to="/login" className="w-full sm:w-auto bg-zinc-900 border border-zinc-800 px-10 py-5 rounded-2xl text-lg font-bold hover:border-zinc-700 transition-all active:scale-95">
              Já sou cliente
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="px-6 py-20 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Zap, title: "Agendamento em 30s", desc: "Seus clientes agendam sem precisar baixar nada, direto pelo navegador." },
            { icon: Smartphone, title: "Mobile First", desc: "Interface otimizada para celulares, com experiência de aplicativo nativo." },
            { icon: DollarSign, title: "Gestão Financeira", desc: "Acompanhe seu faturamento e serviços mais realizados em tempo real." }
          ].map((feature, i) => (
            <div key={i} className="p-8 bg-zinc-900 border border-zinc-800 rounded-3xl space-y-4">
              <div className="w-12 h-12 bg-zinc-100 text-zinc-950 rounded-2xl flex items-center justify-center">
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-zinc-400 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="px-6 py-20 bg-zinc-900/50 border-y border-zinc-900">
        <div className="max-w-xl mx-auto text-center space-y-8">
          <h2 className="text-4xl font-bold tracking-tight">Preço justo e transparente</h2>
          <div className="p-10 bg-zinc-950 border border-zinc-800 rounded-[40px] space-y-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6">
              <span className="px-3 py-1 bg-zinc-100 text-zinc-950 text-[10px] font-bold rounded-full uppercase">Popular</span>
            </div>
            <div className="space-y-2">
              <p className="text-zinc-400 font-medium">Plano Profissional</p>
              <h3 className="text-6xl font-bold tracking-tighter">R$ 49,90<span className="text-xl text-zinc-600">/mês</span></h3>
            </div>
            <ul className="space-y-4 text-left">
              {["Barbeiros ilimitados", "Serviços ilimitados", "Dashboard completo", "Suporte prioritário", "Notificações FCM"].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-zinc-300">
                  <CheckCircle2 size={18} className="text-zinc-100" /> {item}
                </li>
              ))}
            </ul>
            <Link to="/register" className="block w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold hover:bg-zinc-200 transition-all active:scale-95">
              Experimentar 7 dias grátis
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="p-10 text-center text-zinc-600 text-sm">
        <p>© 2026 BarberFlow SaaS. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
