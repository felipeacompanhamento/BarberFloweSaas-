import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Scissors, 
  Clock, 
  LogOut, 
  Menu, 
  X 
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/utils';

import Dashboard from '../components/admin/Dashboard';
import Agenda from '../components/admin/Agenda';
import Barbers from '../components/admin/Barbers';
import Services from '../components/admin/Services';
import Availability from '../components/admin/Availability';

export default function Admin() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const navItems = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/admin/agenda', label: 'Agenda', icon: Calendar },
    { path: '/admin/barbers', label: 'Barbeiros', icon: Users },
    { path: '/admin/services', label: 'Serviços', icon: Scissors },
    { path: '/admin/availability', label: 'Horários', icon: Clock },
  ];

  const Sidebar = ({ className }: { className?: string }) => (
    <div className={cn("flex flex-col h-full bg-zinc-950 border-r border-zinc-900 p-6", className)}>
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
          <Scissors size={20} />
        </div>
        <h1 className="text-xl font-bold tracking-tight">BarberFlow</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all",
                isActive 
                  ? "bg-zinc-100 text-zinc-950 shadow-lg shadow-white/5" 
                  : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={handleLogout}
        className="flex items-center gap-3 px-4 py-3 rounded-2xl font-medium text-red-500 hover:bg-red-500/10 transition-all mt-auto"
      >
        <LogOut size={20} />
        Sair
      </button>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-zinc-950 text-zinc-100">
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-zinc-950/80 backdrop-blur-xl border-b border-zinc-900 flex items-center justify-between px-6 z-50">
        <div className="flex items-center gap-3">
          <Scissors size={20} />
          <span className="font-bold">BarberFlow Admin</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2">
          {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="lg:hidden fixed inset-y-0 left-0 w-72 z-[70]"
            >
              <Sidebar />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-72 flex-shrink-0 sticky top-0 h-screen">
        <Sidebar />
      </div>

      {/* Main Content */}
      <main className="flex-1 p-6 lg:p-10 pt-24 lg:pt-10 overflow-auto">
        <div className="max-w-6xl mx-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/agenda" element={<Agenda />} />
            <Route path="/barbers" element={<Barbers />} />
            <Route path="/services" element={<Services />} />
            <Route path="/availability" element={<Availability />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

