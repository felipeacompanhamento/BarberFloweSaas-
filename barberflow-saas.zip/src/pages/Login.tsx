import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { motion } from 'motion/react';
import { Scissors, LogIn } from 'lucide-react';

export default function Login() {
  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl text-center shadow-2xl"
      >
        <div className="w-16 h-16 bg-zinc-100 text-zinc-950 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Scissors size={32} />
        </div>
        <h1 className="text-2xl font-bold mb-2">Painel Administrativo</h1>
        <p className="text-zinc-400 mb-8">Acesse para gerenciar sua barbearia</p>
        
        <button
          onClick={handleLogin}
          className="w-full bg-zinc-100 text-zinc-950 py-4 px-6 rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-zinc-200 transition-colors active:scale-95"
        >
          <LogIn size={20} />
          Entrar com Google
        </button>
      </motion.div>
    </div>
  );
}
