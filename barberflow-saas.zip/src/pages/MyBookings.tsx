import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, orderBy, Timestamp, deleteDoc, doc, collectionGroup, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Scissors, 
  ChevronRight, 
  Loader2,
  ArrowLeft,
  LogOut,
  Trash2
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { format, isAfter } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import ConfirmationModal from '../components/ConfirmationModal';

import { requestNotificationPermission } from '../lib/notifications';

export default function MyBookings() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');

  // Confirmation State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  useEffect(() => {
    const storedName = localStorage.getItem('barber_client_name');
    const storedPhone = localStorage.getItem('barber_client_phone');

    if (!storedPhone) {
      navigate('/');
      return;
    }

    setClientName(storedName || '');
    setClientPhone(storedPhone);
    
    // Request notification permission using phone number
    requestNotificationPermission(storedPhone);

    const fetchMyBookings = async () => {
      try {
        const q = query(
          collectionGroup(db, 'appointments'),
          where('clientPhone', '==', storedPhone.replace(/\D/g, '')),
          orderBy('startAt', 'desc')
        );
        const snap = await getDocs(q);
        
        // Fetch salon and service details for each appointment
        const apps = await Promise.all(snap.docs.map(async (d) => {
          const data = d.data();
          const salonId = d.ref.parent.parent?.id;
          
          if (!salonId) return null;

          const salonSnap = await getDoc(doc(db, 'salons', salonId));
          const serviceSnap = await getDoc(doc(db, 'salons', salonId, 'services', data.serviceId));
          const barberSnap = await getDoc(doc(db, 'salons', salonId, 'barbers', data.barberId));
          
          return {
            id: d.id,
            path: d.ref.path,
            ...data,
            salon: salonSnap.data(),
            service: serviceSnap.data(),
            barber: barberSnap.data()
          };
        }));

        setAppointments(apps.filter(a => a !== null));
      } catch (err) {
        console.error('Error fetching bookings:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMyBookings();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('barber_client_name');
    localStorage.removeItem('barber_client_phone');
    navigate('/');
  };

  const handleCancel = (appt: any) => {
    setConfirmModal({
      isOpen: true,
      title: 'Cancelar Agendamento',
      message: 'Tem certeza que deseja cancelar este agendamento? Esta ação não pode ser desfeita.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, appt.path));
          setAppointments(prev => prev.filter(a => a.id !== appt.id));
        } catch (err) {
          console.error('Error canceling appointment:', err);
        }
      }
    });
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-zinc-950 text-white"><Loader2 className="animate-spin" /></div>;

  const upcoming = appointments.filter(app => isAfter(app.startAt.toDate(), new Date()));
  const past = appointments.filter(app => !isAfter(app.startAt.toDate(), new Date()));

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 pb-32">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-zinc-950/80 backdrop-blur-xl border-b border-zinc-900 px-6 py-6">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate(-1)}
              className="p-2 hover:bg-zinc-900 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold">Meus Agendamentos</h1>
              <p className="text-sm text-zinc-500">{clientName}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="p-2 text-zinc-500 hover:text-red-400 transition-colors"
            title="Sair"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-8 space-y-10">
        {/* Upcoming */}
        <section>
          <h2 className="text-sm font-bold text-zinc-500 uppercase tracking-wider mb-4">Próximos</h2>
          {upcoming.length === 0 ? (
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 text-center">
              <Calendar className="w-10 h-10 text-zinc-700 mx-auto mb-4" />
              <p className="text-zinc-400">Nenhum agendamento futuro.</p>
              <button 
                onClick={() => {
                  const lastSlug = localStorage.getItem('last_salon_slug');
                  if (lastSlug) {
                    navigate(`/book/${lastSlug}`);
                  } else {
                    navigate('/');
                  }
                }}
                className="mt-4 text-zinc-100 font-bold hover:underline"
              >
                Agendar agora
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {upcoming.map((app) => (
                <AppointmentCard key={app.id} appointment={app} onCancel={() => handleCancel(app)} />
              ))}
            </div>
          )}
        </section>

        {/* Past */}
        {past.length > 0 && (
          <section>
            <h2 className="text-sm font-bold text-zinc-500 uppercase tracking-wider mb-4">Histórico</h2>
            <div className="space-y-4 opacity-60">
              {past.map((app) => (
                <AppointmentCard key={app.id} appointment={app} isPast />
              ))}
            </div>
          </section>
        )}
      </main>

      <ConfirmationModal 
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
      />
    </div>
  );
}

function AppointmentCard({ appointment, isPast, onCancel }: { appointment: any, isPast?: boolean, onCancel?: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "bg-zinc-900 border border-zinc-800 rounded-3xl p-5 flex items-center gap-4",
        isPast && "grayscale"
      )}
    >
      <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex flex-col items-center justify-center text-center">
        <span className="text-xs font-bold text-zinc-500 uppercase">
          {format(appointment.startAt.toDate(), 'MMM', { locale: ptBR })}
        </span>
        <span className="text-xl font-black">
          {format(appointment.startAt.toDate(), 'dd')}
        </span>
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="font-bold truncate">{appointment.salon?.name || 'Salão'}</h3>
        <p className="text-sm text-zinc-400 truncate">{appointment.service?.name}</p>
        <div className="flex items-center gap-3 mt-2 text-xs text-zinc-500">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {format(appointment.startAt.toDate(), 'HH:mm')}
          </span>
          <span className="flex items-center gap-1">
            <Scissors className="w-3 h-3" />
            {appointment.barber?.name}
          </span>
        </div>
      </div>

      {!isPast && (
        <div className="flex flex-col items-end gap-2">
          <div className={cn(
            "px-3 py-1 text-[10px] font-bold uppercase rounded-full",
            appointment.status === 'scheduled' ? "bg-blue-500/10 text-blue-500" :
            appointment.status === 'completed' ? "bg-green-500/10 text-green-500" :
            appointment.status === 'cancelled' ? "bg-red-500/10 text-red-500" :
            appointment.status === 'rescheduled' ? "bg-amber-500/10 text-amber-500" :
            "bg-zinc-500/10 text-zinc-500"
          )}>
            {appointment.status === 'scheduled' ? 'Agendado' :
             appointment.status === 'completed' ? 'Concluído' :
             appointment.status === 'cancelled' ? 'Cancelado' :
             appointment.status === 'rescheduled' ? 'Reagendado' :
             appointment.status === 'no-show' ? 'Não Compareceu' : 'Confirmado'}
          </div>
          {appointment.status === 'scheduled' && (
            <button 
              onClick={onCancel}
              className="p-2 text-zinc-600 hover:text-red-500 transition-colors"
              title="Cancelar Agendamento"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}
