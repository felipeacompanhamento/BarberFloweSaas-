import { useState, useEffect, useRef } from 'react';
import { useNavigate, Routes, Route, Link, useLocation } from 'react-router-dom';
import { collection, query, getDocs, updateDoc, doc, Timestamp, orderBy, where, addDoc, deleteDoc, getDoc, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Scissors, 
  Clock, 
  LogOut, 
  Menu, 
  X, 
  CreditCard,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Plus,
  Trash2,
  DollarSign,
  TrendingUp,
  Search,
  ChevronRight,
  User,
  Upload,
  FileText,
  Package,
  Zap,
  RefreshCw,
  MessageCircle
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { format, isAfter, startOfDay, endOfDay, startOfMonth, endOfMonth, setMinutes, setHours, addMinutes, isBefore, isSameMinute } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import ConfirmationModal from '../components/ConfirmationModal';

export default function SalonPanel() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [salon, setSalon] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  
  // Global Confirmation State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  const salonId = localStorage.getItem('salonId');

  useEffect(() => {
    if (!salonId) {
      navigate('/login');
      return;
    }

    const fetchSalon = async () => {
      try {
        const docRef = doc(db, 'salons', salonId);
        const snap = await getDoc(docRef);
        
        if (!snap.exists()) {
          navigate('/login');
          return;
        }

        const data = snap.data();
        setSalon({ id: snap.id, ...data });
        
        // Check subscription
        const now = new Date();
        const trialExpiresAt = data.trialExpiresAt?.toDate() || now;
        const isTrialExpired = data.status === 'trial' && isAfter(now, trialExpiresAt);
        const isBlockedByAdmin = data.status === 'blocked';
        
        if (isTrialExpired || isBlockedByAdmin) {
          setIsBlocked(true);
        }
      } catch (err) {
        console.error('Error fetching salon:', err);
        // If it's a permission error, maybe the session is invalid
        if (err instanceof Error && err.message.includes('permission')) {
          handleLogout();
        }
      } finally {
        setLoading(false);
      }
    };
    fetchSalon();
  }, [salonId, navigate]);

  const handleLogout = () => {
    localStorage.removeItem('salonId');
    localStorage.removeItem('salonName');
    navigate('/login');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-zinc-950"><Loader2 className="animate-spin" /></div>;

  if (isBlocked) {
    return <SubscriptionBlock salon={salon} onLogout={handleLogout} />;
  }

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-zinc-950 border-r border-zinc-900 p-6">
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center overflow-hidden">
          {salon.logoUrl ? (
            <img src={salon.logoUrl} alt={salon.name} className="w-full h-full object-cover" />
          ) : (
            <Scissors size={20} />
          )}
        </div>
        <h1 className="text-xl font-bold tracking-tight">{salon.name}</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {[
          { path: '/salon', label: 'Dashboard', icon: LayoutDashboard },
          { path: '/salon/agenda', label: 'Agenda', icon: Calendar },
          { path: '/salon/barbers', label: 'Barbeiros', icon: Users },
          { path: '/salon/services', label: 'Serviços', icon: Scissors },
          { path: '/salon/products', label: 'Produtos', icon: Package },
          { path: '/salon/availability', label: 'Horários', icon: Clock },
          { path: '/salon/reports', label: 'Relatórios', icon: FileText },
          { path: '/salon/subscription', label: 'Assinatura', icon: CreditCard },
        ].map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all",
                isActive 
                  ? "bg-zinc-100 text-zinc-950" 
                  : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto space-y-4">
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-2">
          <p className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest">Link de Agendamento</p>
          <button 
            onClick={() => {
              const url = `${window.location.origin}/book/${salon.slug}`;
              navigator.clipboard.writeText(url);
            }}
            className="text-xs text-zinc-100 font-medium truncate w-full text-left flex items-center gap-2 hover:text-zinc-400 transition-colors"
          >
            <Search size={12} /> Copiar Link
          </button>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-2xl font-medium text-red-500 hover:bg-red-500/10 transition-all w-full"
        >
          <LogOut size={20} />
          Sair
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-zinc-950 text-zinc-100">
      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="lg:hidden fixed inset-y-0 left-0 w-72 z-[70]"
            >
              <Sidebar />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="hidden lg:block w-72 flex-shrink-0 sticky top-0 h-screen">
        <Sidebar />
      </div>

      <main className="flex-1 p-6 lg:p-10 overflow-auto">
        <div className="lg:hidden flex items-center justify-between mb-8">
          <h1 className="font-bold">{salon.name}</h1>
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 bg-zinc-900 rounded-xl">
            <Menu size={24} />
          </button>
        </div>

        <Routes>
          <Route path="/" element={<SalonDashboard salonId={salon.id} />} />
          <Route path="/agenda" element={<SalonAgenda salonId={salon.id} onConfirm={setConfirmModal} />} />
          <Route path="/barbers" element={<SalonBarbers salonId={salon.id} onConfirm={setConfirmModal} />} />
          <Route path="/services" element={<SalonServices salonId={salon.id} onConfirm={setConfirmModal} />} />
          <Route path="/products" element={<SalonProducts salonId={salon.id} onConfirm={setConfirmModal} />} />
          <Route path="/availability" element={<SalonAvailability salonId={salon.id} onConfirm={setConfirmModal} />} />
          <Route path="/reports" element={<SalonReports salonId={salon.id} />} />
          <Route path="/subscription" element={<SalonSubscription salon={salon} />} />
        </Routes>

        <ConfirmationModal 
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          message={confirmModal.message}
        />
      </main>
    </div>
  );
}

function SubscriptionBlock({ salon, onLogout }: { salon: any, onLogout: () => void }) {
  const [paying, setPaying] = useState(false);
  const [pixData, setPixData] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    const fetchPending = async () => {
      try {
        const q = query(
          collection(db, 'payments'),
          where('salonId', '==', salon.id),
          where('status', '==', 'pending'),
          orderBy('createdAt', 'desc'),
          limit(1)
        );
        const snap = await getDocs(q);
        if (!snap.empty) {
          setPixData({ id: snap.docs[0].id, ...snap.docs[0].data() } as any);
        }
      } catch (err) {
        console.error('Error fetching pending payment:', err);
      }
    };
    fetchPending();
  }, [salon.id]);

  const handlePay = async () => {
    setPaying(true);
    try {
      const res = await fetch('/api/payments/create-pix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          salonId: salon.id,
          email: salon.ownerPhone + '@barberflow.com'
        })
      });
      const data = await res.json();
      if (!res.ok) throw data;
      setPixData(data);
    } catch (err: any) {
      console.error('Error generating PIX:', err);
      const errorMsg = err.details || err.mpError?.message || err.error || 'Erro ao gerar PIX. Verifique se o administrador configurou as chaves corretamente.';
      alert(`Erro: ${errorMsg}`);
    } finally {
      setPaying(false);
    }
  };

  const verifyPayment = async () => {
    if (!pixData?.id || verifying) return;
    setVerifying(true);
    try {
      const res = await fetch(`/api/payments/verify/${pixData.id}`);
      const data = await res.json();
      if (data.status === 'paid') {
        alert('Pagamento confirmado! Seu acesso foi liberado.');
        window.location.reload();
      }
    } catch (err) {
      console.error('Error verifying payment:', err);
    } finally {
      setVerifying(false);
    }
  };

  useEffect(() => {
    let interval: any;
    if (pixData?.id && pixData.status === 'pending') {
      interval = setInterval(verifyPayment, 10000);
    }
    return () => clearInterval(interval);
  }, [pixData]);

  const copyToClipboard = () => {
    if (pixData?.qrCode) {
      navigator.clipboard.writeText(pixData.qrCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-6">
      <div className="max-w-md w-full space-y-8 text-center">
        <div className="space-y-4">
          <div className="w-20 h-20 bg-red-500/10 text-red-500 rounded-[32px] flex items-center justify-center mx-auto">
            <AlertCircle size={40} />
          </div>
          <h1 className="text-4xl font-black tracking-tighter">Acesso Restrito</h1>
          <p className="text-zinc-400">Seu período de teste expirou ou sua assinatura está pendente.</p>
        </div>

        {!pixData ? (
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-8 space-y-6">
            <div className="space-y-1">
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Plano Profissional</p>
              <h2 className="text-3xl font-black">R$ 49,90<span className="text-sm font-medium text-zinc-500">/mês</span></h2>
            </div>
            <button 
              onClick={handlePay}
              disabled={paying}
              className="w-full py-6 bg-zinc-100 text-zinc-950 rounded-[24px] font-black text-sm uppercase tracking-widest hover:bg-white transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {paying ? <Loader2 className="animate-spin" size={20} /> : <Zap size={20} />}
              Ativar Agora via PIX
            </button>
          </div>
        ) : (
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white p-4 rounded-3xl flex flex-col items-center gap-4 shadow-xl">
              {pixData.qrCodeBase64 && (
                <img src={`data:image/png;base64,${pixData.qrCodeBase64}`} alt="QR Code PIX" className="w-48 h-48" />
              )}
              <p className="text-[10px] text-zinc-400 text-center uppercase font-bold tracking-widest">Escaneie o código acima para pagar</p>
            </div>

            <div className="space-y-2">
              <button 
                onClick={copyToClipboard}
                className="w-full py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2"
              >
                {copied ? <CheckCircle2 size={16} /> : <FileText size={16} />}
                {copied ? 'Copiado!' : 'Copiar Código PIX'}
              </button>
              
              <button 
                onClick={verifyPayment}
                disabled={verifying}
                className="w-full py-3 bg-zinc-800 text-white rounded-2xl font-bold text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-700 transition-colors"
              >
                {verifying ? <Loader2 className="animate-spin" size={14} /> : <RefreshCw size={14} />}
                Já paguei, verificar agora
              </button>

              <p className="text-[10px] text-zinc-500 text-center italic">O acesso será liberado automaticamente após o pagamento.</p>
            </div>
          </div>
        )}

        <button onClick={onLogout} className="text-zinc-500 hover:text-zinc-100 text-sm font-medium transition-colors">
          Sair da Conta
        </button>
      </div>
    </div>
  );
}

function SalonSubscription({ salon }: { salon: any }) {
  const [loading, setLoading] = useState(false);
  const [payment, setPayment] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [copied, setCopied] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const fetchPayments = async () => {
    try {
      const q = query(
        collection(db, 'payments'),
        where('salonId', '==', salon.id),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      const docs = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      setHistory(docs);
      
      const pending = docs.find(d => d.status === 'pending');
      if (pending) {
        setPayment(pending);
      } else {
        setPayment(null);
      }
    } catch (err) {
      console.error('Error fetching payments:', err);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, [salon.id]);

  const generatePix = async () => {
    if (payment) return;
    setLoading(true);
    try {
      const res = await fetch('/api/payments/create-pix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          salonId: salon.id,
          email: salon.ownerPhone + '@barberflow.com'
        })
      });
      const data = await res.json();
      if (!res.ok) throw data;
      setPayment(data);
      fetchPayments(); // Refresh history
    } catch (err: any) {
      console.error('Error generating PIX:', err);
      const errorMsg = err.details || err.mpError?.message || err.error || 'Erro ao gerar PIX. Verifique se o administrador configurou as chaves corretamente.';
      alert(`Erro: ${errorMsg}`);
    } finally {
      setLoading(false);
    }
  };

  const verifyPayment = async () => {
    if (!payment?.id || verifying) return;
    setVerifying(true);
    try {
      const res = await fetch(`/api/payments/verify/${payment.id}`);
      const data = await res.json();
      if (data.status === 'paid') {
        alert('Pagamento confirmado! Sua assinatura foi renovada.');
        fetchPayments(); // Refresh to update status
        window.location.reload();
      }
    } catch (err) {
      console.error('Error verifying payment:', err);
    } finally {
      setVerifying(true);
      setTimeout(() => setVerifying(false), 2000);
    }
  };

  useEffect(() => {
    let interval: any;
    if (payment?.id && payment.status === 'pending') {
      interval = setInterval(verifyPayment, 15000); // Poll every 15s
    }
    return () => clearInterval(interval);
  }, [payment]);

  const copyToClipboard = () => {
    if (payment?.qrCode) {
      navigator.clipboard.writeText(payment.qrCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const status = salon.status;
  const trialExpiresAt = salon.trialExpiresAt?.toDate();
  const isTrial = status === 'trial';
  const daysLeft = trialExpiresAt ? Math.ceil((trialExpiresAt.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : 0;

  const lastPayment = history[0];
  const daysSinceLast = lastPayment ? Math.floor((new Date().getTime() - lastPayment.createdAt.toDate().getTime()) / (1000 * 60 * 60 * 24)) : 999;
  const canGenerate = !payment && daysSinceLast >= 30;

  return (
    <div className="max-w-4xl space-y-10 pb-20">
      <div className="flex flex-col gap-2">
        <h2 className="text-4xl font-black tracking-tight text-white">Assinatura <span className="text-zinc-500 font-medium text-lg ml-2">Premium Access</span></h2>
        <p className="text-zinc-400">Mantenha seu salão ativo e aproveite todos os recursos.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-10 space-y-8">
          <div className="space-y-4">
            <div className={cn(
              "w-16 h-16 rounded-3xl flex items-center justify-center",
              status === 'active' ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"
            )}>
              {status === 'active' ? <CheckCircle2 size={32} /> : <Clock size={32} />}
            </div>
            <div>
              <h3 className="text-2xl font-bold">Status: {status === 'active' ? 'Ativo' : 'Trial'}</h3>
              {isTrial && (
                <p className="text-zinc-400 mt-1">Seu período de teste expira em <span className="text-white font-bold">{daysLeft} dias</span>.</p>
              )}
              {status === 'active' && trialExpiresAt && (
                <p className="text-zinc-400 mt-1">Próxima renovação em: <span className="text-white font-bold">{format(trialExpiresAt, 'dd/MM/yyyy')}</span></p>
              )}
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-zinc-800">
            <h4 className="text-xs font-black text-zinc-500 uppercase tracking-widest">Recursos Inclusos</h4>
            <ul className="space-y-3">
              {[
                'Agendamentos Ilimitados',
                'Gestão de Barbeiros e Serviços',
                'Catálogo de Produtos Premium',
                'Relatórios de Comissões',
                'Notificações WhatsApp/Push',
                'Suporte Prioritário'
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-zinc-300">
                  <CheckCircle2 size={16} className="text-emerald-500" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-zinc-100 text-zinc-950 rounded-[40px] p-10 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
            <Zap size={120} />
          </div>
          
          <div className="space-y-2 relative z-10">
            <span className="text-[10px] font-black uppercase tracking-widest px-3 py-1 bg-zinc-950 text-white rounded-full">Plano Profissional</span>
            <h3 className="text-4xl font-black tracking-tighter">R$ 49,90<span className="text-lg font-medium text-zinc-500">/mês</span></h3>
          </div>

          <div className="space-y-6 relative z-10 pt-10">
            {!payment ? (
              <div className="space-y-4">
                <button 
                  onClick={generatePix}
                  disabled={loading || !canGenerate}
                  className="w-full py-6 bg-zinc-950 text-white rounded-[24px] font-black text-sm uppercase tracking-widest hover:bg-zinc-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <Zap size={20} />}
                  Gerar PIX de Pagamento
                </button>
                {!canGenerate && lastPayment && (
                  <p className="text-[10px] text-zinc-500 text-center font-bold uppercase tracking-widest">
                    Novo PIX disponível em {30 - daysSinceLast} dias
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="bg-white p-4 rounded-3xl flex flex-col items-center gap-4 shadow-xl">
                  {payment.qrCodeBase64 && (
                    <img src={`data:image/png;base64,${payment.qrCodeBase64}`} alt="QR Code PIX" className="w-48 h-48" />
                  )}
                  <p className="text-[10px] text-zinc-400 text-center uppercase font-bold tracking-widest">Escaneie o código acima para pagar</p>
                </div>

                <div className="space-y-2">
                  <button 
                    onClick={copyToClipboard}
                    className="w-full py-4 bg-zinc-950 text-white rounded-2xl font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    {copied ? <CheckCircle2 size={16} /> : <FileText size={16} />}
                    {copied ? 'Copiado!' : 'Copiar Código PIX'}
                  </button>

                  <button 
                    onClick={verifyPayment}
                    disabled={verifying}
                    className="w-full py-3 bg-zinc-200 text-zinc-950 rounded-2xl font-bold text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-white transition-colors"
                  >
                    {verifying ? <Loader2 className="animate-spin" size={14} /> : <RefreshCw size={14} />}
                    Já paguei, verificar agora
                  </button>

                  <p className="text-[10px] text-zinc-500 text-center italic">O status será atualizado automaticamente após o pagamento.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Payment History */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-center text-zinc-400">
            <FileText size={20} />
          </div>
          <h3 className="text-xl font-bold">Histórico de Pagamentos</h3>
        </div>

        <div className="bg-zinc-900/30 border border-zinc-800 rounded-[32px] overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-zinc-800 bg-zinc-900/50">
                <th className="p-6 text-[10px] font-black text-zinc-500 uppercase tracking-widest">Data</th>
                <th className="p-6 text-[10px] font-black text-zinc-500 uppercase tracking-widest">Valor</th>
                <th className="p-6 text-[10px] font-black text-zinc-500 uppercase tracking-widest">Status</th>
                <th className="p-6 text-[10px] font-black text-zinc-500 uppercase tracking-widest">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {history.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-10 text-center text-zinc-500 text-sm italic">Nenhum pagamento registrado.</td>
                </tr>
              ) : (
                history.map((pay) => (
                  <tr key={pay.id} className="hover:bg-zinc-800/30 transition-colors">
                    <td className="p-6 text-sm font-medium">{format(pay.createdAt.toDate(), 'dd/MM/yyyy HH:mm')}</td>
                    <td className="p-6 text-sm font-bold">R$ {pay.amount.toFixed(2)}</td>
                    <td className="p-6">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                        pay.status === 'paid' ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"
                      )}>
                        {pay.status === 'paid' ? 'Pago' : 'Pendente'}
                      </span>
                    </td>
                    <td className="p-6">
                      {pay.status === 'pending' && (
                        <button 
                          onClick={() => setPayment(pay)}
                          className="text-[10px] font-black uppercase tracking-widest text-blue-400 hover:text-blue-300 transition-colors"
                        >
                          Ver PIX
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// --- Sub-components for Salon Panel ---

function SalonDashboard({ salonId }: { salonId: string }) {
  const [stats, setStats] = useState({ totalAppointments: 0, totalRevenue: 0, activeBarbers: 0, totalServices: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const now = new Date();
        const start = startOfMonth(now);
        const end = endOfMonth(now);

        const qAppts = query(
          collection(db, 'salons', salonId, 'appointments'),
          where('startAt', '>=', Timestamp.fromDate(start)),
          where('startAt', '<=', Timestamp.fromDate(end))
        );
        const apptsSnapshot = await getDocs(qAppts);
        const appts = apptsSnapshot.docs.map(doc => doc.data());

        const qBarbers = query(collection(db, 'salons', salonId, 'barbers'), where('active', '==', true));
        const barbersSnapshot = await getDocs(qBarbers);

        const qServices = query(collection(db, 'salons', salonId, 'services'));
        const servicesSnapshot = await getDocs(qServices);
        const services = servicesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        let revenue = 0;
        appts.forEach((appt: any) => {
          if (appt.status === 'completed') {
            const service = services.find((s: any) => s.id === appt.serviceId) as any;
            if (service) revenue += service.price;
          }
        });

        setStats({
          totalAppointments: appts.length,
          totalRevenue: revenue,
          activeBarbers: barbersSnapshot.size,
          totalServices: servicesSnapshot.size
        });
      } catch (err) {
        console.error('Error fetching dashboard stats:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, [salonId]);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Agendamentos (Mês)', value: stats.totalAppointments, icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-500/10' },
          { label: 'Faturamento (Mês)', value: formatCurrency(stats.totalRevenue), icon: DollarSign, color: 'text-green-500', bg: 'bg-green-500/10' },
          { label: 'Barbeiros Ativos', value: stats.activeBarbers, icon: Users, color: 'text-purple-500', bg: 'bg-purple-500/10' },
          { label: 'Serviços', value: stats.totalServices, icon: Scissors, color: 'text-orange-500', bg: 'bg-orange-500/10' },
        ].map((stat, i) => (
          <div key={i} className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-4", stat.bg, stat.color)}>
              <stat.icon size={24} />
            </div>
            <p className="text-zinc-400 text-sm font-medium">{stat.label}</p>
            <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
          </div>
        ))}
      </div>
    </div>
  );
}

// Re-implementing simplified versions of Agenda, Barbers, Services, Availability with salonId filter
// (In a real app, these would be separate files or generic components)

function SalonAgenda({ salonId, onConfirm }: { salonId: string, onConfirm: any }) {
  const [loading, setLoading] = useState(true);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [filterDate, setFilterDate] = useState<Date>(startOfDay(new Date()));
  const [filterBarber, setFilterBarber] = useState('all');
  const [showExpired, setShowExpired] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAppt, setEditingAppt] = useState<any>(null);

  // Manual creation state
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [selectedBarberId, setSelectedBarberId] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [selectedTime, setSelectedTime] = useState('09:00');
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);

  useEffect(() => {
    const fetchSlots = async () => {
      console.log('Fetching slots for:', selectedBarberId, selectedDate);
      if (!selectedBarberId || !selectedDate) return;
      
      try {
        // 1. Fetch availability
        const qA = query(collection(db, 'salons', salonId, 'availability'), where('barberId', '==', selectedBarberId));
        const snapA = await getDocs(qA);
        const availData = snapA.docs.map(d => d.data());
        console.log('AvailData:', availData);
        
        const dayOfWeek = new Date(selectedDate + ' 00:00:00').getDay();
        console.log('DayOfWeek:', dayOfWeek);
        const barberAvail = availData.find(a => a.dayOfWeek === dayOfWeek);
        
        if (!barberAvail) {
          setAvailableSlots([]);
          return;
        }

        // 2. Fetch appointments
        const start = startOfDay(new Date(selectedDate + ' 00:00:00'));
        const end = endOfDay(new Date(selectedDate + ' 00:00:00'));
        const qAppt = query(
          collection(db, 'salons', salonId, 'appointments'),
          where('barberId', '==', selectedBarberId),
          where('startAt', '>=', Timestamp.fromDate(start)),
          where('startAt', '<=', Timestamp.fromDate(end))
        );
        const snapAppt = await getDocs(qAppt);
        const appts = snapAppt.docs.map(d => ({id: d.id, ...d.data()})).filter((a: any) => a.status === 'scheduled');

        // 3. Calculate slots
        const slots = [];
        let currentTime = new Date(selectedDate + ' ' + barberAvail.startTime + ':00');
        const endTime = new Date(selectedDate + ' ' + barberAvail.endTime + ':00');
        
        while (isBefore(currentTime, endTime)) {
          const timeStr = format(currentTime, 'HH:mm');
          const isBooked = appts.some((a: any) => {
            if (editingAppt && a.id === editingAppt.id) return false;
            const startAt = a.startAt.toDate();
            const endAt = a.endAt.toDate();
            return isSameMinute(currentTime, startAt) || (isAfter(currentTime, startAt) && isBefore(currentTime, endAt));
          });
          
          if (!isBooked) {
            slots.push(timeStr);
          }
          currentTime = addMinutes(currentTime, 30); // Assuming 30 min slots
        }
        setAvailableSlots(slots);
        if (slots.length > 0 && !slots.includes(selectedTime)) {
          setSelectedTime(slots[0]);
        }
      } catch (err) {
        console.error('Error fetching available slots:', err);
      }
    };
    fetchSlots();
  }, [selectedBarberId, selectedDate, editingAppt]);

  // Client search state
  const [clients, setClients] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showClientResults, setShowClientResults] = useState(false);

  useEffect(() => {
    const fetchInitial = async () => {
      try {
        const qB = query(collection(db, 'salons', salonId, 'barbers'));
        const snapB = await getDocs(qB);
        const bData = snapB.docs.map(d => ({ id: d.id, ...d.data() }));
        setBarbers(bData);
        if (bData.length > 0) setSelectedBarberId(bData[0].id);

        const qS = query(collection(db, 'salons', salonId, 'services'));
        const snapS = await getDocs(qS);
        setServices(snapS.docs.map(d => ({ id: d.id, ...d.data() })));

        const qC = query(collection(db, 'clients'), orderBy('name', 'asc'));
        const snapC = await getDocs(qC);
        setClients(snapC.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching initial agenda data:', err);
      }
    };
    fetchInitial();
  }, [salonId]);

  useEffect(() => {
    const fetchAppointments = async () => {
      setLoading(true);
      try {
        const now = new Date();
        
        let q;
        if (showExpired) {
          // Fetch all past scheduled appointments regardless of date
          q = query(
            collection(db, 'salons', salonId, 'appointments'),
            where('status', '==', 'scheduled'),
            where('endAt', '<', Timestamp.fromDate(now)),
            orderBy('endAt', 'desc')
          );
        } else {
          // Normal daily view
          const start = startOfDay(filterDate);
          const end = endOfDay(filterDate);
          q = query(
            collection(db, 'salons', salonId, 'appointments'),
            where('startAt', '>=', Timestamp.fromDate(start)),
            where('startAt', '<=', Timestamp.fromDate(end)),
            orderBy('startAt', 'asc')
          );
        }

        if (filterBarber !== 'all') {
          q = query(q, where('barberId', '==', filterBarber));
        }

        const snapshot = await getDocs(q);
        setAppointments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any })));
      } catch (err) {
        console.error('Error fetching appointments:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAppointments();
  }, [salonId, filterDate, filterBarber, showExpired]);

  const updateStatus = async (apptId: string, newStatus: string) => {
    const appt = appointments.find(a => a.id === apptId);
    if (!appt) return;

    // If already in a "final" status, user said it cannot be undone
    if (['cancelled', 'rescheduled', 'no-show'].includes(appt.status)) {
      return;
    }

    const performUpdate = async () => {
      try {
        await updateDoc(doc(db, 'salons', salonId, 'appointments', apptId), { 
          status: newStatus,
          updatedAt: Timestamp.now()
        });
        setAppointments(prev => prev.map(a => a.id === apptId ? { ...a, status: newStatus } : a));
      } catch (err) {
        console.error('Error updating status:', err);
      }
    };

    if (['cancelled', 'rescheduled', 'no-show'].includes(newStatus)) {
      onConfirm({
        isOpen: true,
        title: 'Confirmar Mudança de Status',
        message: `Tem certeza que deseja alterar o status para "${statusLabels[newStatus]}"? Esta ação não poderá ser desfeita e o horário ficará disponível para outros clientes.`,
        onConfirm: performUpdate
      });
    } else {
      performUpdate();
    }
  };

  const handleSave = async () => {
    if (!clientName || !clientPhone || !selectedBarberId || !selectedServiceId) return;
    
    const [h, m] = selectedTime.split(':');
    const dateObj = new Date(selectedDate + 'T00:00:00');
    const startAt = setMinutes(setHours(dateObj, Number(h)), Number(m));
    const service = services.find(s => s.id === selectedServiceId);
    const endAt = addMinutes(startAt, service?.durationMinutes || 30);

    if (isBefore(startAt, new Date()) && !editingAppt) {
      alert('Não é possível criar agendamentos no passado.');
      return;
    }

    const apptData = {
      clientName,
      clientPhone: clientPhone.replace(/\D/g, ''),
      barberId: selectedBarberId,
      serviceId: selectedServiceId,
      startAt: Timestamp.fromDate(startAt),
      endAt: Timestamp.fromDate(endAt),
      status: editingAppt ? editingAppt.status : 'scheduled',
      updatedAt: Timestamp.now()
    };

    try {
      if (editingAppt) {
        await updateDoc(doc(db, 'salons', salonId, 'appointments', editingAppt.id), apptData);
      } else {
        await addDoc(collection(db, 'salons', salonId, 'appointments'), { ...apptData, createdAt: Timestamp.now() });
      }

      // Automatically register client if new
      const cleanPhone = clientPhone.replace(/\D/g, '');
      const existingClient = clients.find(c => c.phone === cleanPhone);
      if (!existingClient) {
        const newClient = {
          name: clientName,
          phone: cleanPhone,
          createdAt: Timestamp.now()
        };
        const clientRef = await addDoc(collection(db, 'clients'), newClient);
        setClients(prev => [...prev, { id: clientRef.id, ...newClient }].sort((a, b) => a.name.localeCompare(b.name)));
      }

      setIsModalOpen(false);
      setEditingAppt(null);
      setClientName('');
      setClientPhone('');
      setSearchQuery('');
      setShowClientResults(false);
      // Refresh
      setFilterDate(new Date(filterDate));
    } catch (err) {
      console.error('Error saving appointment:', err);
      alert('Erro ao salvar agendamento. Verifique sua conexão ou permissões.');
    }
  };

  const openEdit = (appt: any) => {
    setEditingAppt(appt);
    setClientName(appt.clientName);
    setClientPhone(appt.clientPhone);
    setSelectedBarberId(appt.barberId);
    setSelectedServiceId(appt.serviceId);
    setSelectedTime(format(appt.startAt.toDate(), 'HH:mm'));
    setSelectedDate(format(appt.startAt.toDate(), 'yyyy-MM-dd'));
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Agendamento',
      message: 'Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'salons', salonId, 'appointments', id));
          setAppointments(prev => prev.filter(a => a.id !== id));
        } catch (err) {
          console.error('Error deleting appointment:', err);
        }
      }
    });
  };

  const filteredAppointments = appointments;

  const statusLabels: Record<string, string> = {
    'scheduled': 'Agendado',
    'completed': 'Concluído',
    'cancelled': 'Cancelado',
    'rescheduled': 'Reagendado',
    'no-show': 'Não compareceu'
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold">Agenda</h2>
          <button 
            onClick={() => setShowExpired(!showExpired)}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-bold border transition-all",
              showExpired ? "bg-red-500/10 border-red-500/20 text-red-500" : "bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300"
            )}
          >
            {showExpired ? "Mostrando Não Concluídos" : "Serviços Não Concluídos"}
          </button>
        </div>
        <div className="flex items-center gap-2">
          <select 
            value={filterBarber} 
            onChange={e => setFilterBarber(e.target.value)}
            className="bg-zinc-900 border border-zinc-800 rounded-xl p-2 text-sm"
          >
            <option value="all">Todos Barbeiros</option>
            {barbers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <input
            type="date"
            value={format(filterDate, 'yyyy-MM-dd')}
            onChange={e => setFilterDate(new Date(e.target.value + 'T00:00:00'))}
            className="bg-zinc-900 border border-zinc-800 rounded-xl p-2 text-sm"
          />
          <button 
            onClick={() => { setEditingAppt(null); setIsModalOpen(true); }}
            className="p-2 bg-zinc-100 text-zinc-950 rounded-xl hover:bg-zinc-200 transition-colors"
          >
            <Plus size={20} />
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>
        ) : filteredAppointments.length === 0 ? (
          <div className="text-center py-20 bg-zinc-900/50 border border-dashed border-zinc-800 rounded-[40px]">
            <Calendar className="mx-auto text-zinc-700 mb-4" size={40} />
            <p className="text-zinc-500">{showExpired ? "Nenhum serviço atrasado pendente." : "Nenhum agendamento para este dia."}</p>
          </div>
        ) : (
          filteredAppointments.map(appt => {
            const barber = barbers.find(b => b.id === appt.barberId);
            const service = services.find(s => s.id === appt.serviceId);
            return (
              <div 
                key={appt.id} 
                className="bg-zinc-900 border border-zinc-800 p-5 rounded-3xl flex items-center justify-between hover:border-zinc-700 transition-all group"
              >
                <div className="flex items-center gap-4 flex-1 cursor-pointer" onClick={() => openEdit(appt)}>
                  <div className="text-center min-w-[60px] pr-4 border-r border-zinc-800">
                    <p className="text-lg font-bold">{format(appt.startAt.toDate(), 'HH:mm')}</p>
                    <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">{format(appt.endAt.toDate(), 'HH:mm')}</p>
                  </div>
                  <div>
                    <p className="font-bold text-zinc-100">{appt.clientName}</p>
                    <p className="text-xs text-zinc-500">{service?.name} • {barber?.name}</p>
                  </div>
                </div>
                <div className="flex flex-col md:flex-row md:items-center gap-4 w-full md:w-auto">
                  <div className="relative">
                    <select
                      value={appt.status}
                      disabled={['cancelled', 'rescheduled', 'no-show'].includes(appt.status)}
                      onChange={(e) => updateStatus(appt.id, e.target.value)}
                      className={cn(
                        "appearance-none px-4 py-2 pr-10 rounded-2xl text-[10px] font-bold uppercase tracking-widest border transition-all cursor-pointer disabled:cursor-not-allowed",
                        appt.status === 'scheduled' ? "bg-blue-500/10 border-blue-500/20 text-blue-500" :
                        appt.status === 'completed' ? "bg-green-500/10 border-green-500/20 text-green-500" :
                        appt.status === 'cancelled' ? "bg-red-500/10 border-red-500/20 text-red-500" :
                        appt.status === 'rescheduled' ? "bg-amber-500/10 border-amber-500/20 text-amber-500" :
                        "bg-zinc-800 border-zinc-700 text-zinc-400"
                      )}
                    >
                      {Object.entries(statusLabels).map(([value, label]) => (
                        <option key={value} value={value} className="bg-zinc-900 text-zinc-100">
                          {label}
                        </option>
                      ))}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                      <ChevronRight size={14} className="rotate-90" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-auto md:ml-0">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        const salonName = 'Nosso Salão';
                        const text = `Olá, ${appt.clientName}! 💇‍♂️✨
Somente para confirmar seu agendamento em nosso salão!
📅 Data: ${format(appt.startAt.toDate(), 'dd/MM')}
⏰ Horário: ${format(appt.startAt.toDate(), 'HH:mm')}
💼 Serviço: ${service?.name}
👤 Profissional: ${barber?.name}
Estamos te esperando! 😊
Caso precise remarcar ou cancelar, é só nos avisar com antecedência.
Até breve!
${salonName}`;
                        window.open(`https://wa.me/55${appt.clientPhone}?text=${encodeURIComponent(text)}`, '_blank');
                      }}
                      className="p-2 text-zinc-700 hover:text-green-500 transition-colors"
                      title="Enviar WhatsApp"
                    >
                      <MessageCircle size={16} />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(appt.id);
                      }}
                      className="p-2 text-zinc-700 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                    <button onClick={() => openEdit(appt)} className="p-2 text-zinc-700 hover:text-zinc-100 transition-colors">
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
              <h3 className="text-xl font-bold">{editingAppt ? 'Editar Agendamento' : 'Novo Agendamento'}</h3>
              
              <div className="space-y-4">
                <div className="space-y-2 relative">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Pesquisar Cliente</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={16} />
                    <input 
                      value={searchQuery} 
                      onChange={e => {
                        setSearchQuery(e.target.value);
                        setShowClientResults(true);
                        // Also update name if it's a new client
                        if (!editingAppt) setClientName(e.target.value);
                      }} 
                      onFocus={() => setShowClientResults(true)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 pl-10 text-sm" 
                      placeholder="Pesquisar por nome ou WhatsApp..." 
                    />
                  </div>
                  {showClientResults && searchQuery.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-zinc-900 border border-zinc-800 rounded-xl shadow-xl max-h-48 overflow-y-auto">
                      {clients
                        .filter(c => 
                          c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.phone.includes(searchQuery.replace(/\D/g, ''))
                        )
                        .map(c => (
                          <button
                            key={c.id}
                            onClick={() => {
                              setClientName(c.name);
                              setClientPhone(c.phone);
                              setSearchQuery('');
                              setShowClientResults(false);
                            }}
                            className="w-full text-left p-3 hover:bg-zinc-800 text-sm border-b border-zinc-800 last:border-0"
                          >
                            <p className="font-bold">{c.name}</p>
                            <p className="text-xs text-zinc-500">{c.phone}</p>
                          </button>
                        ))
                      }
                      {clients.filter(c => 
                          c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.phone.includes(searchQuery.replace(/\D/g, ''))
                        ).length === 0 && (
                        <div className="p-3 text-xs text-zinc-500 italic">Nenhum cliente encontrado. Digite abaixo para cadastrar.</div>
                      )}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Nome do Cliente</label>
                    <input value={clientName} onChange={e => setClientName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="Nome" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">WhatsApp</label>
                    <input value={clientPhone} onChange={e => setClientPhone(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="Telefone" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Barbeiro</label>
                  <select value={selectedBarberId} onChange={e => setSelectedBarberId(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm">
                    {barbers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Serviço</label>
                  <select value={selectedServiceId} onChange={e => setSelectedServiceId(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm">
                    <option value="">Selecione um serviço</option>
                    {services.map(s => <option key={s.id} value={s.id}>{s.name} - {formatCurrency(s.price)}</option>)}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Data</label>
                    <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Horário</label>
                    <select value={selectedTime} onChange={e => setSelectedTime(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm">
                      {availableSlots.length > 0 ? (
                        availableSlots.map(slot => <option key={slot} value={slot}>{slot}</option>)
                      ) : (
                        <option value="">Nenhum horário disponível</option>
                      )}
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SalonBarbers({ salonId, onConfirm }: { salonId: string, onConfirm: any }) {
  const [barbers, setBarbers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBarber, setEditingBarber] = useState<any>(null);
  const [name, setName] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [active, setActive] = useState(true);
  const [commissionType, setCommissionType] = useState<'percentage' | 'fixed'>('percentage');
  const [commissionValue, setCommissionValue] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetch = async () => {
      try {
        const q = query(collection(db, 'salons', salonId, 'barbers'));
        const snap = await getDocs(q);
        setBarbers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching barbers:', err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [salonId]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 300;
        canvas.height = 300;
        if (ctx) {
          const size = Math.min(img.width, img.height);
          const offsetX = (img.width - size) / 2;
          const offsetY = (img.height - size) / 2;
          ctx.drawImage(img, offsetX, offsetY, size, size, 0, 0, 300, 300);
          setPhoto(canvas.toDataURL('image/webp', 0.8));
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!name) return;
    const data = { 
      name, 
      photoUrl: photo, 
      active,
      commissionType,
      commissionValue: Number(commissionValue) || 0
    };
    try {
      if (editingBarber) {
        await updateDoc(doc(db, 'salons', salonId, 'barbers', editingBarber.id), data);
      } else {
        await addDoc(collection(db, 'salons', salonId, 'barbers'), data);
      }
      setIsModalOpen(false);
      setEditingBarber(null);
      setName('');
      setPhoto(null);
      // Refresh
      const q = query(collection(db, 'salons', salonId, 'barbers'));
      const snap = await getDocs(q);
      setBarbers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error('Error saving barber:', err);
      alert('Erro ao salvar barbeiro. Verifique suas permissões.');
    }
  };

  const openEdit = (barber: any) => {
    setEditingBarber(barber);
    setName(barber.name);
    setPhoto(barber.photoUrl);
    setActive(barber.active);
    setCommissionType(barber.commissionType || 'percentage');
    setCommissionValue(barber.commissionValue?.toString() || '');
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Barbeiro',
      message: 'Tem certeza que deseja excluir este barbeiro? Esta ação não pode ser desfeita.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'salons', salonId, 'barbers', id));
          setBarbers(prev => prev.filter(b => b.id !== id));
        } catch (err) {
          console.error('Error deleting barber:', err);
        }
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Barbeiros</h2>
        <button onClick={() => { setEditingBarber(null); setName(''); setPhoto(null); setActive(true); setIsModalOpen(true); }} className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-xl font-bold flex items-center gap-2">
          <Plus size={20} /> Novo Barbeiro
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {barbers.map(b => (
          <div key={b.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-[32px] space-y-4 relative group">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-zinc-950 rounded-2xl overflow-hidden border border-zinc-800">
                {b.photoUrl ? <img src={b.photoUrl} className="w-full h-full object-cover" /> : <User className="w-full h-full p-4 text-zinc-700" />}
              </div>
              <div>
                <h3 className="font-bold">{b.name}</h3>
                <span className={cn("text-[10px] font-bold uppercase tracking-widest", b.active ? "text-green-500" : "text-zinc-500")}>
                  {b.active ? 'Ativo' : 'Inativo'}
                </span>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => openEdit(b)} className="flex-1 py-2 bg-zinc-800 rounded-xl text-xs font-bold hover:bg-zinc-700 transition-colors">Editar</button>
              <button onClick={() => handleDelete(b.id)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6">
              <h3 className="text-xl font-bold">{editingBarber ? 'Editar Barbeiro' : 'Novo Barbeiro'}</h3>
              
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div onClick={() => fileInputRef.current?.click()} className="w-24 h-24 bg-zinc-950 border-2 border-dashed border-zinc-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-zinc-100 transition-all overflow-hidden relative">
                    {photo ? <img src={photo} className="w-full h-full object-cover" /> : <Upload className="text-zinc-500" />}
                  </div>
                  <input type="file" ref={fileInputRef} onChange={handlePhotoChange} className="hidden" accept="image/*" />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Nome</label>
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="Nome do Barbeiro" />
                </div>

                <div className="flex items-center gap-3">
                  <input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} id="active" className="w-4 h-4 rounded bg-zinc-950 border-zinc-800" />
                  <label htmlFor="active" className="text-sm font-bold text-zinc-400">Barbeiro Ativo</label>
                </div>

                <div className="space-y-3 pt-2 border-t border-zinc-800">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Comissão</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setCommissionType('percentage')}
                      className={cn(
                        "flex-1 py-2 rounded-xl text-xs font-bold border transition-all",
                        commissionType === 'percentage' ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-950 border-zinc-800 text-zinc-500"
                      )}
                    >
                      Porcentagem (%)
                    </button>
                    <button
                      onClick={() => setCommissionType('fixed')}
                      className={cn(
                        "flex-1 py-2 rounded-xl text-xs font-bold border transition-all",
                        commissionType === 'fixed' ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-950 border-zinc-800 text-zinc-500"
                      )}
                    >
                      Fixo (R$)
                    </button>
                  </div>
                  <input 
                    type="number" 
                    value={commissionValue} 
                    onChange={e => setCommissionValue(e.target.value)} 
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" 
                    placeholder={commissionType === 'percentage' ? "Ex: 30" : "Ex: 15.00"} 
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SalonServices({ salonId, onConfirm }: { salonId: string, onConfirm: any }) {
  const [services, setServices] = useState<any[]>([]);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<any>(null);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('30');
  const [selectedBarberIds, setSelectedBarberIds] = useState<string[]>([]);

  useEffect(() => {
    const fetch = async () => {
      try {
        const qS = query(collection(db, 'salons', salonId, 'services'));
        const snapS = await getDocs(qS);
        setServices(snapS.docs.map(d => ({ id: d.id, ...d.data() })));

        const qB = query(collection(db, 'salons', salonId, 'barbers'));
        const snapB = await getDocs(qB);
        setBarbers(snapB.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching services/barbers:', err);
      }
    };
    fetch();
  }, [salonId]);

  const handleSave = async () => {
    if (!name || !price) return;
    const data = { 
      name, 
      price: Number(price), 
      durationMinutes: Number(duration),
      barberIds: selectedBarberIds
    };
    try {
      if (editingService) {
        await updateDoc(doc(db, 'salons', salonId, 'services', editingService.id), data);
      } else {
        await addDoc(collection(db, 'salons', salonId, 'services'), data);
      }
      setIsModalOpen(false);
      setEditingService(null);
      setName('');
      setPrice('');
      setSelectedBarberIds([]);
      // Refresh
      const q = query(collection(db, 'salons', salonId, 'services'));
      const snap = await getDocs(q);
      setServices(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error('Error saving service:', err);
      alert('Erro ao salvar serviço. Verifique suas permissões.');
    }
  };

  const openEdit = (service: any) => {
    setEditingService(service);
    setName(service.name);
    setPrice(service.price.toString());
    setDuration(service.durationMinutes.toString());
    setSelectedBarberIds(service.barberIds || []);
    setIsModalOpen(true);
  };

  const toggleBarber = (id: string) => {
    setSelectedBarberIds(prev => 
      prev.includes(id) ? prev.filter(bId => bId !== id) : [...prev, id]
    );
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Serviço',
      message: 'Tem certeza que deseja excluir este serviço? Esta ação não pode ser desfeita.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'salons', salonId, 'services', id));
          setServices(prev => prev.filter(s => s.id !== id));
        } catch (err) {
          console.error('Error deleting service:', err);
        }
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Serviços</h2>
        <button onClick={() => { setEditingService(null); setName(''); setPrice(''); setDuration('30'); setIsModalOpen(true); }} className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-xl font-bold flex items-center gap-2">
          <Plus size={20} /> Novo Serviço
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {services.map(s => (
          <div key={s.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-[32px] flex items-center justify-between hover:border-zinc-700 transition-all group">
            <div onClick={() => openEdit(s)} className="flex-1 cursor-pointer">
              <h3 className="font-bold text-lg">{s.name}</h3>
              <p className="text-sm text-zinc-500">{s.durationMinutes} min • {formatCurrency(s.price)}</p>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(s.id);
                }}
                className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"
              >
                <Trash2 size={16} />
              </button>
              <ChevronRight size={20} className="text-zinc-700 group-hover:text-zinc-100 transition-colors cursor-pointer" onClick={() => openEdit(s)} />
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6">
              <h3 className="text-xl font-bold">{editingService ? 'Editar Serviço' : 'Novo Serviço'}</h3>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Nome do Serviço</label>
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="Ex: Corte de Cabelo" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Preço (R$)</label>
                    <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="0.00" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Duração (min)</label>
                    <input type="number" value={duration} onChange={e => setDuration(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="30" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Barbeiros que realizam</label>
                  <div className="grid grid-cols-2 gap-2">
                    {barbers.map(barber => (
                      <button
                        key={barber.id}
                        type="button"
                        onClick={() => toggleBarber(barber.id)}
                        className={cn(
                          "px-3 py-2 rounded-xl text-xs font-bold border transition-all",
                          selectedBarberIds.includes(barber.id) 
                            ? "bg-zinc-100 border-zinc-100 text-zinc-950" 
                            : "bg-zinc-950 border-zinc-800 text-zinc-500 hover:border-zinc-700"
                        )}
                      >
                        {barber.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SalonAvailability({ salonId, onConfirm }: { salonId: string, onConfirm: any }) {
  const [availability, setAvailability] = useState<any[]>([]);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAvail, setEditingAvail] = useState<any>(null);
  
  const [barberId, setBarberId] = useState('');
  const [dayOfWeek, setDayOfWeek] = useState('1');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('18:00');

  useEffect(() => {
    const fetch = async () => {
      try {
        const qB = query(collection(db, 'salons', salonId, 'barbers'));
        const snapB = await getDocs(qB);
        const bData = snapB.docs.map(d => ({ id: d.id, ...d.data() }));
        setBarbers(bData);
        if (bData.length > 0) setBarberId(bData[0].id);

        const qA = query(collection(db, 'salons', salonId, 'availability'));
        const snapA = await getDocs(qA);
        setAvailability(snapA.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching availability/barbers:', err);
      }
    };
    fetch();
  }, [salonId]);

  const handleSave = async () => {
    if (!barberId) return;
    const data = { barberId, dayOfWeek: Number(dayOfWeek), startTime, endTime };
    if (editingAvail) {
      await updateDoc(doc(db, 'salons', salonId, 'availability', editingAvail.id), data);
    } else {
      await addDoc(collection(db, 'salons', salonId, 'availability'), data);
    }
    setIsModalOpen(false);
    setEditingAvail(null);
    // Refresh
    const qA = query(collection(db, 'salons', salonId, 'availability'));
    const snapA = await getDocs(qA);
    setAvailability(snapA.docs.map(d => ({ id: d.id, ...d.data() })));
  };

  const openEdit = (avail: any) => {
    setEditingAvail(avail);
    setBarberId(avail.barberId);
    setDayOfWeek(avail.dayOfWeek.toString());
    setStartTime(avail.startTime);
    setEndTime(avail.endTime);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Horário',
      message: 'Tem certeza que deseja excluir este horário de funcionamento?',
      onConfirm: async () => {
        console.log('Deleting availability:', id);
        try {
          await deleteDoc(doc(db, 'salons', salonId, 'availability', id));
          setAvailability(prev => prev.filter(a => a.id !== id));
        } catch (err) {
          console.error('Error deleting availability:', err);
        }
      }
    });
  };

  const days = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Horários de Funcionamento</h2>
        <button onClick={() => { setEditingAvail(null); setIsModalOpen(true); }} className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-xl font-bold flex items-center gap-2">
          <Plus size={20} /> Novo Horário
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {availability.map(a => {
          const barber = barbers.find(b => b.id === a.barberId);
          return (
            <div key={a.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-[32px] flex items-center justify-between hover:border-zinc-700 transition-all group">
              <div onClick={() => openEdit(a)} className="flex-1 cursor-pointer">
                <h3 className="font-bold text-lg">{barber?.name}</h3>
                <p className="text-sm text-zinc-500">{days[a.dayOfWeek]} • {a.startTime} às {a.endTime}</p>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(a.id);
                  }} 
                  className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"
                >
                  <Trash2 size={16} />
                </button>
                <ChevronRight size={20} className="text-zinc-700 group-hover:text-zinc-100 transition-colors cursor-pointer" onClick={() => openEdit(a)} />
              </div>
            </div>
          );
        })}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6">
              <h3 className="text-xl font-bold">{editingAvail ? 'Editar Horário' : 'Novo Horário'}</h3>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Barbeiro</label>
                  <select value={barberId} onChange={e => setBarberId(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm">
                    {barbers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Dia da Semana</label>
                  <select value={dayOfWeek} onChange={e => setDayOfWeek(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm">
                    {days.map((day, i) => <option key={i} value={i}>{day}</option>)}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Início</label>
                    <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Fim</label>
                    <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SalonReports({ salonId }: { salonId: string }) {
  const [barbers, setBarbers] = useState<any[]>([]);
  const [selectedBarberId, setSelectedBarberId] = useState('all');
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), 'yyyy-MM-dd'));
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<any[]>([]);
  const [summary, setSummary] = useState({ totalRevenue: 0, totalCommission: 0, count: 0 });

  useEffect(() => {
    const fetchBarbers = async () => {
      try {
        const q = query(collection(db, 'salons', salonId, 'barbers'));
        const snap = await getDocs(q);
        setBarbers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching barbers for reports:', err);
      }
    };
    fetchBarbers();
  }, [salonId]);

  const generateReport = async () => {
    setLoading(true);
    try {
      const start = startOfDay(new Date(startDate + 'T00:00:00'));
      const end = endOfDay(new Date(endDate + 'T23:59:59'));

      let q = query(
        collection(db, 'salons', salonId, 'appointments'),
        where('status', '==', 'completed'),
        where('startAt', '>=', Timestamp.fromDate(start)),
        where('startAt', '<=', Timestamp.fromDate(end)),
        orderBy('startAt', 'desc')
      );

      if (selectedBarberId !== 'all') {
        q = query(q, where('barberId', '==', selectedBarberId));
      }

      const snapshot = await getDocs(q);
      const appts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Fetch services to get prices
      const servicesSnap = await getDocs(query(collection(db, 'salons', salonId, 'services')));
      const servicesMap = servicesSnap.docs.reduce((acc: any, d) => {
        acc[d.id] = d.data();
        return acc;
      }, {});

      let totalRev = 0;
      let totalComm = 0;

      const detailedData = appts.map((appt: any) => {
        const service = servicesMap[appt.serviceId];
        const barber = barbers.find(b => b.id === appt.barberId);
        const price = service?.price || 0;
        
        let commission = 0;
        if (barber) {
          if (barber.commissionType === 'percentage') {
            commission = (price * (barber.commissionValue || 0)) / 100;
          } else if (barber.commissionType === 'fixed') {
            commission = barber.commissionValue || 0;
          }
        }

        totalRev += price;
        totalComm += commission;

        return {
          ...appt,
          serviceName: service?.name || 'Serviço Excluído',
          barberName: barber?.name || 'Barbeiro Excluído',
          price,
          commission
        };
      });

      setReportData(detailedData);
      setSummary({ totalRevenue: totalRev, totalCommission: totalComm, count: appts.length });
    } catch (err) {
      console.error('Error generating report:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-3xl font-bold tracking-tight">Relatórios de Comissões</h2>
        <button 
          onClick={generateReport}
          disabled={loading}
          className="bg-zinc-100 text-zinc-950 px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-zinc-200 transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <Search size={20} />}
          Gerar Relatório
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <label className="text-xs font-bold text-zinc-500 uppercase">Barbeiro</label>
          <select 
            value={selectedBarberId} 
            onChange={e => setSelectedBarberId(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-zinc-100 transition-all"
          >
            <option value="all">Todos os Barbeiros</option>
            {barbers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-zinc-500 uppercase">Data Inicial</label>
          <input 
            type="date" 
            value={startDate} 
            onChange={e => setStartDate(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-zinc-100 transition-all"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-zinc-500 uppercase">Data Final</label>
          <input 
            type="date" 
            value={endDate} 
            onChange={e => setEndDate(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-zinc-100 transition-all"
          />
        </div>
      </div>

      {reportData.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
              <p className="text-zinc-400 text-sm font-medium">Total de Atendimentos</p>
              <h3 className="text-2xl font-bold mt-1">{summary.count}</h3>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
              <p className="text-zinc-400 text-sm font-medium">Faturamento Total</p>
              <h3 className="text-2xl font-bold mt-1 text-green-500">{formatCurrency(summary.totalRevenue)}</h3>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl">
              <p className="text-zinc-400 text-sm font-medium">Comissões a Pagar</p>
              <h3 className="text-2xl font-bold mt-1 text-blue-500">{formatCurrency(summary.totalCommission)}</h3>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-[40px] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-800">
                    <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-wider">Data</th>
                    <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-wider">Barbeiro</th>
                    <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-wider">Serviço</th>
                    <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-wider">Valor</th>
                    <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-wider">Comissão</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {reportData.map((item) => (
                    <tr key={item.id} className="hover:bg-zinc-800/30 transition-colors">
                      <td className="p-6 text-sm">
                        {format(item.startAt.toDate(), 'dd/MM/yyyy HH:mm')}
                      </td>
                      <td className="p-6 text-sm font-medium">{item.barberName}</td>
                      <td className="p-6 text-sm text-zinc-400">{item.serviceName}</td>
                      <td className="p-6 text-sm font-bold">{formatCurrency(item.price)}</td>
                      <td className="p-6 text-sm font-bold text-blue-400">{formatCurrency(item.commission)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      )}

      {!loading && reportData.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
          <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center text-zinc-700">
            <FileText size={40} />
          </div>
          <div className="space-y-1">
            <h3 className="text-xl font-bold">Nenhum dado encontrado</h3>
            <p className="text-zinc-500 max-w-xs">Selecione os filtros e clique em gerar relatório para visualizar os resultados.</p>
          </div>
        </div>
      )}
    </div>
  );
}

function SalonProducts({ salonId, onConfirm }: { salonId: string, onConfirm: any }) {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [active, setActive] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetch = async () => {
      try {
        const q = query(collection(db, 'salons', salonId, 'products'), orderBy('name', 'asc'));
        const snap = await getDocs(q);
        setProducts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error('Error fetching products:', err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [salonId]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 400;
        canvas.height = 400;
        if (ctx) {
          const size = Math.min(img.width, img.height);
          const offsetX = (img.width - size) / 2;
          const offsetY = (img.height - size) / 2;
          ctx.drawImage(img, offsetX, offsetY, size, size, 0, 0, 400, 400);
          setPhoto(canvas.toDataURL('image/webp', 0.8));
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!name || !price) return;
    const data = { 
      name, 
      description,
      price: Number(price), 
      photoUrl: photo, 
      active
    };
    try {
      if (editingProduct) {
        await updateDoc(doc(db, 'salons', salonId, 'products', editingProduct.id), data);
      } else {
        await addDoc(collection(db, 'salons', salonId, 'products'), data);
      }
      setIsModalOpen(false);
      setEditingProduct(null);
      setName('');
      setDescription('');
      setPrice('');
      setPhoto(null);
      // Refresh
      const q = query(collection(db, 'salons', salonId, 'products'), orderBy('name', 'asc'));
      const snap = await getDocs(q);
      setProducts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error('Error saving product:', err);
      alert('Erro ao salvar produto. Verifique suas permissões.');
    }
  };

  const openEdit = (product: any) => {
    setEditingProduct(product);
    setName(product.name);
    setDescription(product.description || '');
    setPrice(product.price.toString());
    setPhoto(product.photoUrl);
    setActive(product.active);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Produto',
      message: 'Tem certeza que deseja excluir este produto do catálogo?',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'salons', salonId, 'products', id));
          setProducts(prev => prev.filter(p => p.id !== id));
        } catch (err) {
          console.error('Error deleting product:', err);
        }
      }
    });
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Catálogo de Produtos</h2>
        <button onClick={() => { setEditingProduct(null); setName(''); setDescription(''); setPrice(''); setPhoto(null); setActive(true); setIsModalOpen(true); }} className="bg-zinc-100 text-zinc-950 px-6 py-3 rounded-xl font-bold flex items-center gap-2">
          <Plus size={20} /> Novo Produto
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full flex justify-center py-20"><Loader2 className="animate-spin" /></div>
        ) : products.length === 0 ? (
          <div className="col-span-full text-center py-20 bg-zinc-900/50 border border-dashed border-zinc-800 rounded-[40px]">
            <Package className="mx-auto text-zinc-700 mb-4" size={40} />
            <p className="text-zinc-500">Nenhum produto cadastrado no catálogo.</p>
          </div>
        ) : (
          products.map(p => (
            <div key={p.id} className="bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden flex flex-col group">
              <div className="aspect-square bg-zinc-950 relative overflow-hidden">
                {p.photoUrl ? (
                  <img src={p.photoUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-800">
                    <Package size={48} />
                  </div>
                )}
                {!p.active && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <span className="px-4 py-2 bg-zinc-100 text-zinc-950 rounded-full text-xs font-bold uppercase tracking-widest">Inativo</span>
                  </div>
                )}
              </div>
              <div className="p-6 space-y-4 flex-1 flex flex-col">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-lg">{p.name}</h3>
                    <span className="text-zinc-100 font-bold">{formatCurrency(p.price)}</span>
                  </div>
                  <p className="text-sm text-zinc-400 line-clamp-2">{p.description}</p>
                </div>
                <div className="flex gap-2 mt-auto pt-4">
                  <button onClick={() => openEdit(p)} className="flex-1 py-3 bg-zinc-800 rounded-xl text-xs font-bold hover:bg-zinc-700 transition-colors">Editar</button>
                  <button onClick={() => handleDelete(p.id)} className="p-3 text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"><Trash2 size={18} /></button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
              <h3 className="text-xl font-bold">{editingProduct ? 'Editar Produto' : 'Novo Produto'}</h3>
              
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div onClick={() => fileInputRef.current?.click()} className="w-32 h-32 bg-zinc-950 border-2 border-dashed border-zinc-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-zinc-100 transition-all overflow-hidden relative">
                    {photo ? <img src={photo} className="w-full h-full object-cover" /> : <Upload className="text-zinc-500" />}
                  </div>
                  <input type="file" ref={fileInputRef} onChange={handlePhotoChange} className="hidden" accept="image/*" />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Nome do Produto</label>
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="Ex: Pomada Modeladora" />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Descrição</label>
                  <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm min-h-[100px]" placeholder="Descreva o produto..." />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Preço (R$)</label>
                  <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" placeholder="0.00" />
                </div>

                <div className="flex items-center gap-3">
                  <input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} id="prod-active" className="w-4 h-4 rounded bg-zinc-950 border-zinc-800" />
                  <label htmlFor="prod-active" className="text-sm font-bold text-zinc-400">Produto Ativo no Catálogo</label>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
