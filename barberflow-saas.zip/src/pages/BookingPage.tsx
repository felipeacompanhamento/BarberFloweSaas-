import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, addDoc, Timestamp, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { requestNotificationPermission } from '../lib/notifications';
import { 
  Scissors, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight,
  Loader2,
  ChevronRight,
  Star,
  ExternalLink,
  AlertCircle,
  Package,
  ShoppingBag,
  X
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { format, addMinutes, startOfDay, endOfDay, eachMinuteOfInterval, isSameMinute, isAfter, setHours, setMinutes, parse, isBefore } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function BookingPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [salon, setSalon] = useState<any>(null);
  const [barbers, setBarbers] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [availability, setAvailability] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Selection state
  const [selectedBarber, setSelectedBarber] = useState<any>(null);
  const [selectedService, setSelectedService] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(startOfDay(new Date()));
  const [selectedTime, setSelectedTime] = useState<Date | null>(null);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);

  // Expose selectedProduct to the window or a global context if needed, 
  // but here we can just add a class to the body or use a custom event.
  // Actually, a simpler way is to pass this state to a context or just use a custom event.
  useEffect(() => {
    if (selectedProduct) {
      document.body.classList.add('hide-bottom-nav');
    } else {
      document.body.classList.remove('hide-bottom-nav');
    }
  }, [selectedProduct]);

  const isIOS = typeof navigator !== 'undefined' && (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));
  const isAndroid = typeof navigator !== 'undefined' && /Android/.test(navigator.userAgent);

  useEffect(() => {
    if (!bookingSuccess) return;
    
    // Small delay to ensure the success screen is visible
    const timer = setTimeout(() => {
      if (isAndroid) {
        // For Android, we can't easily auto-redirect to a URL without user gesture being blocked
      } else if (isIOS) {
        // For iOS, downloading the ICS might work better
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [bookingSuccess, isAndroid, isIOS]);

  const generateGoogleCalendarLink = () => {
    if (!selectedTime || !selectedService || !salon) return '';
    const start = selectedTime.toISOString().replace(/-|:|\.\d\d\d/g, '');
    const end = addMinutes(selectedTime, selectedService.durationMinutes).toISOString().replace(/-|:|\.\d\d\d/g, '');
    const text = encodeURIComponent(`${selectedService.name} - ${salon.name}`);
    const details = encodeURIComponent(`Serviço: ${selectedService.name}\nBarbeiro: ${selectedBarber?.name}\nLocal: ${salon.address}`);
    const location = encodeURIComponent(salon.address || '');
    return `https://www.google.com/calendar/render?action=TEMPLATE&text=${text}&details=${details}&location=${location}&dates=${start}/${end}`;
  };

  const downloadIcsFile = () => {
    if (!selectedTime || !selectedService || !salon) return;
    const start = selectedTime.toISOString().replace(/-|:|\.\d\d\d/g, '');
    const end = addMinutes(selectedTime, selectedService.durationMinutes).toISOString().replace(/-|:|\.\d\d\d/g, '');
    
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'BEGIN:VEVENT',
      `DTSTART:${start}`,
      `DTEND:${end}`,
      `SUMMARY:${selectedService.name} - ${salon.name}`,
      `DESCRIPTION:Serviço: ${selectedService.name}\\nBarbeiro: ${selectedBarber?.name}`,
      `LOCATION:${salon.address}`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'agendamento.ics');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  useEffect(() => {
    const fetchSalonData = async () => {
      if (!slug) return;
      
      const salonSnap = await getDocs(query(collection(db, 'salons'), where('slug', '==', slug)));
      if (salonSnap.empty) {
        navigate('/');
        return;
      }
      const salonData = { id: salonSnap.docs[0].id, ...salonSnap.docs[0].data() } as any;
      setSalon(salonData);

      // Save for navigation
      localStorage.setItem('last_salon_slug', slug);
      localStorage.setItem('last_salon_name', salonData.name);

      // PWA Branding & Client-side Meta
      if (salonData.name) document.title = salonData.name;
      
      const updateMeta = (name: string, content: string, attr = 'name') => {
        let el = document.querySelector(`meta[${attr}="${name}"]`);
        if (!el) {
          el = document.createElement('meta');
          el.setAttribute(attr, name);
          document.head.appendChild(el);
        }
        el.setAttribute('content', content);
      };

      updateMeta('og:title', salonData.name, 'property');
      updateMeta('og:description', `Agende seu horário na ${salonData.name} pelo BarberFlow.`, 'property');
      
      const logoToUse = salonData.logoUrl || '/logo.svg';
      updateMeta('og:image', logoToUse, 'property');
      
      let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = logoToUse;

      let appleLink = document.querySelector("link[rel~='apple-touch-icon']") as HTMLLinkElement;
      if (!appleLink) {
        appleLink = document.createElement('link');
        appleLink.rel = 'apple-touch-icon';
        document.getElementsByTagName('head')[0].appendChild(appleLink);
      }
      appleLink.href = logoToUse;

      const barbersSnap = await getDocs(query(collection(db, 'salons', salonData.id, 'barbers'), where('active', '==', true)));
      setBarbers(barbersSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      const servicesSnap = await getDocs(query(collection(db, 'salons', salonData.id, 'services')));
      setServices(servicesSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      const availSnap = await getDocs(query(collection(db, 'salons', salonData.id, 'availability')));
      setAvailability(availSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      const productsSnap = await getDocs(query(collection(db, 'salons', salonData.id, 'products'), where('active', '==', true)));
      setProducts(productsSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      // Pre-fill client info from localStorage
      const storedName = localStorage.getItem('barber_client_name');
      const storedPhone = localStorage.getItem('barber_client_phone');
      if (storedName) setClientName(storedName);
      if (storedPhone) setClientPhone(storedPhone);

      setLoading(false);
    };
    fetchSalonData();
  }, [slug, navigate]);

  useEffect(() => {
    const fetchAppointments = async () => {
      if (!salon || !selectedBarber) return;
      const start = startOfDay(selectedDate);
      const end = endOfDay(selectedDate);
      const q = query(
        collection(db, 'salons', salon.id, 'appointments'),
        where('barberId', '==', selectedBarber.id),
        where('startAt', '>=', Timestamp.fromDate(start)),
        where('startAt', '<=', Timestamp.fromDate(end))
      );
      const snap = await getDocs(q);
      const apps = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      setAppointments(apps.filter(app => !['cancelled', 'rescheduled', 'no-show'].includes(app.status)));
    };
    fetchAppointments();
  }, [salon, selectedBarber, selectedDate]);

  const handleBooking = async () => {
    if (!selectedBarber || !selectedService || !selectedTime || !clientName || !clientPhone) return;
    setBookingLoading(true);

    try {
      const startAt = selectedTime;
      const endAt = addMinutes(startAt, selectedService.durationMinutes);

      if (isBefore(startAt, new Date())) {
        setError('Não é possível agendar para um horário que já passou.');
        setBookingLoading(false);
        return;
      }

      // Final check before confirming
      const q = query(
        collection(db, 'salons', salon.id, 'appointments'),
        where('barberId', '==', selectedBarber.id),
        where('startAt', '>=', Timestamp.fromDate(startOfDay(selectedDate))),
        where('startAt', '<=', Timestamp.fromDate(endOfDay(selectedDate)))
      );
      const snap = await getDocs(q);
      const existing = snap.docs
        .map(d => ({ id: d.id, ...d.data() } as any))
        .filter(app => !['cancelled', 'rescheduled', 'no-show'].includes(app.status));
      
      const hasConflict = existing.some((app: any) => {
        const appStart = app.startAt.toDate();
        const appEnd = app.endAt.toDate();
        // Overlap logic: s1 < e2 && s2 < e1
        return isBefore(startAt, appEnd) && isBefore(appStart, endAt);
      });

      if (hasConflict) {
        console.error('Time slot already filled');
        setBookingLoading(false);
        // Refresh appointments
        setAppointments(existing);
        return;
      }

      await addDoc(collection(db, 'salons', salon.id, 'appointments'), {
        barberId: selectedBarber.id,
        serviceId: selectedService.id,
        clientName,
        clientPhone: clientPhone.replace(/\D/g, ''),
        startAt: Timestamp.fromDate(startAt),
        endAt: Timestamp.fromDate(endAt),
        status: 'scheduled',
        createdAt: Timestamp.now()
      });

      // Save client info to localStorage
      localStorage.setItem('barber_client_name', clientName);
      localStorage.setItem('barber_client_phone', clientPhone);

      // Show success screen immediately
      setBookingSuccess(true);

      // Request notification permission in the background
      requestNotificationPermission(clientPhone).catch(err => {
        console.error('Notification permission error:', err);
      });
    } catch (err) {
      console.error('Booking error:', err);
      setError('Ocorreu um erro ao realizar o agendamento. Por favor, tente novamente.');
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-zinc-950"><Loader2 className="animate-spin" /></div>;

  if (bookingSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-zinc-950 text-zinc-100 pb-32">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="max-w-md w-full text-center space-y-8">
          <div className="w-24 h-24 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 size={48} />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Agendado com sucesso!</h2>
            <p className="text-zinc-400">
              Tudo certo, {clientName}. Te esperamos no dia {selectedTime ? format(selectedTime, "dd 'de' MMMM", { locale: ptBR }) : ''} às {selectedTime ? format(selectedTime, 'HH:mm') : ''}.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 pt-4">
            <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">
              {isIOS ? 'Adicionar ao Calendário do iPhone' : isAndroid ? 'Adicionar ao Google Agenda' : 'Adicionar à sua agenda'}
            </p>
            
            {(isAndroid || !isIOS) && (
              <a 
                href={generateGoogleCalendarLink()} 
                target="_blank" 
                rel="noopener noreferrer"
                className={cn(
                  "flex items-center justify-center gap-3 p-5 rounded-2xl transition-all group",
                  isAndroid ? "bg-zinc-100 text-zinc-950" : "bg-zinc-900 border border-zinc-800 text-zinc-100 hover:border-zinc-700"
                )}
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", isAndroid ? "bg-blue-500/10 text-blue-500" : "bg-blue-500/10 text-blue-500")}>
                  <Calendar size={18} />
                </div>
                <span className="font-bold text-sm">Google Agenda</span>
                <ExternalLink size={14} className="text-zinc-600 group-hover:text-zinc-400 ml-auto" />
              </a>
            )}

            {(isIOS || !isAndroid) && (
              <button 
                onClick={downloadIcsFile}
                className={cn(
                  "flex items-center justify-center gap-3 p-5 rounded-2xl transition-all group",
                  isIOS ? "bg-zinc-100 text-zinc-950" : "bg-zinc-900 border border-zinc-800 text-zinc-100 hover:border-zinc-700"
                )}
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", isIOS ? "bg-zinc-950/10 text-zinc-950" : "bg-zinc-100/10 text-zinc-100")}>
                  <Calendar size={18} />
                </div>
                <span className="font-bold text-sm">Apple / iPhone Agenda</span>
                <ExternalLink size={14} className="text-zinc-600 group-hover:text-zinc-400 ml-auto" />
              </button>
            )}
          </div>

          <div className="pt-8 space-y-3">
            <button onClick={() => navigate('/my-bookings')} className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold hover:bg-zinc-200 transition-all active:scale-95">
              Ver Meus Agendamentos
            </button>
            <button onClick={() => navigate('/')} className="w-full bg-transparent text-zinc-500 py-3 rounded-2xl font-bold hover:text-zinc-300 transition-all">
              Voltar ao Início
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 pb-32">
      {/* Header */}
      <AnimatePresence>
        {!selectedProduct && (
          <motion.header 
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            className="p-6 border-b border-zinc-900 sticky top-0 bg-zinc-950/80 backdrop-blur-xl z-50"
          >
            <div className="max-w-2xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-center overflow-hidden">
                  {salon.logoUrl ? (
                    <img src={salon.logoUrl} alt={salon.name} className="w-full h-full object-cover" />
                  ) : (
                    <Scissors size={20} />
                  )}
                </div>
                <div>
                  <h1 className="font-bold text-lg">{salon.name}</h1>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Agendamento Online</p>
                </div>
              </div>
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Passo {step} de 4</div>
            </div>
          </motion.header>
        )}
      </AnimatePresence>

      <main className="max-w-2xl mx-auto p-6 space-y-8">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="space-y-2">
                <h2 className="text-2xl font-bold tracking-tight">Escolha o Serviço</h2>
                <p className="text-sm text-zinc-500">{salon.address}</p>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {services.map(service => (
                  <button
                    key={service.id}
                    onClick={() => { setSelectedService(service); setStep(2); }}
                    className={cn(
                      "p-6 rounded-3xl border text-left flex items-center justify-between transition-all active:scale-[0.98]",
                      selectedService?.id === service.id ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-900 border-zinc-800 hover:border-zinc-700"
                    )}
                  >
                    <div>
                      <h3 className="font-bold text-lg">{service.name}</h3>
                      <p className={cn("text-sm", selectedService?.id === service.id ? "text-zinc-600" : "text-zinc-500")}>
                        {service.durationMinutes} min • {formatCurrency(service.price)}
                      </p>
                    </div>
                    <ChevronRight size={20} className={cn(selectedService?.id === service.id ? "text-zinc-950" : "text-zinc-700")} />
                  </button>
                ))}
              </div>

              {products.length > 0 && (
                <div className="pt-10 space-y-6">
                  <div className="flex items-center gap-2 border-b border-zinc-900 pb-4">
                    <ShoppingBag size={20} className="text-zinc-100" />
                    <h2 className="text-xl font-bold tracking-tight">Nossos Produtos</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {products.map(product => (
                      <motion.div 
                        key={product.id} 
                        whileHover={{ y: -4 }}
                        onClick={() => setSelectedProduct(product)}
                        className="bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden flex flex-col cursor-pointer group hover:border-zinc-700 transition-all"
                      >
                        <div className="aspect-square bg-zinc-950 relative overflow-hidden">
                          {product.photoUrl ? (
                            <img src={product.photoUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-zinc-800">
                              <Package size={32} />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                            <span className="text-[10px] font-black text-white uppercase tracking-widest bg-zinc-900/80 backdrop-blur-md px-3 py-1 rounded-full">Ver Detalhes</span>
                          </div>
                        </div>
                        <div className="p-5 space-y-1.5">
                          <h3 className="font-black text-sm tracking-tight text-zinc-100">{product.name}</h3>
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">{formatCurrency(product.price)}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {/* Product Details Modal */}
              <AnimatePresence>
                {selectedProduct && (
                  <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center sm:p-6">
                    <motion.div 
                      initial={{ opacity: 0 }} 
                      animate={{ opacity: 1 }} 
                      exit={{ opacity: 0 }} 
                      onClick={() => setSelectedProduct(null)} 
                      className="absolute inset-0 bg-black/90 backdrop-blur-md" 
                    />
                    <motion.div 
                      initial={{ y: '100%', opacity: 0 }} 
                      animate={{ y: 0, opacity: 1 }} 
                      exit={{ y: '100%', opacity: 0 }} 
                      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                      className="relative bg-zinc-900 border-t sm:border border-zinc-800 w-full max-w-2xl sm:rounded-[40px] rounded-t-[40px] overflow-y-auto max-h-[95vh] shadow-2xl no-scrollbar"
                    >
                      <button 
                        onClick={() => setSelectedProduct(null)}
                        className="absolute top-6 right-6 z-20 w-12 h-12 bg-white/10 backdrop-blur-xl text-white rounded-full flex items-center justify-center hover:bg-white/20 transition-all border border-white/10"
                      >
                        <X size={24} />
                      </button>

                      <div className="grid grid-cols-1 md:grid-cols-2">
                        <div className="aspect-square bg-zinc-950 relative md:h-full">
                          {selectedProduct.photoUrl ? (
                            <img src={selectedProduct.photoUrl} alt={selectedProduct.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-zinc-800">
                              <Package size={80} />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent md:hidden" />
                        </div>

                        <div className="p-8 sm:p-10 space-y-8 flex flex-col justify-center">
                          <div className="space-y-4">
                            <div className="space-y-1">
                              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em] bg-emerald-400/10 px-3 py-1 rounded-full">Disponível em Estoque</span>
                              <h3 className="text-3xl sm:text-4xl font-black tracking-tighter text-white leading-none pt-2">{selectedProduct.name}</h3>
                            </div>
                            
                            <div className="flex items-baseline gap-2">
                              <span className="text-3xl font-black text-zinc-100">{formatCurrency(selectedProduct.price)}</span>
                              <span className="text-xs text-zinc-500 font-medium">Preço Unitário</span>
                            </div>
                          </div>

                          <div className="space-y-4">
                            <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] border-b border-zinc-800 pb-2">Sobre este produto</h4>
                            <p className="text-zinc-400 text-base leading-relaxed font-medium">
                              {selectedProduct.description || "Este produto foi selecionado cuidadosamente por nossos especialistas para garantir o melhor resultado para você."}
                            </p>
                          </div>

                          <div className="pt-4">
                            <button 
                              onClick={() => setSelectedProduct(null)}
                              className="w-full py-6 bg-white text-zinc-950 rounded-[24px] font-black text-sm uppercase tracking-widest hover:bg-zinc-200 transition-all active:scale-95 shadow-[0_0_40px_rgba(255,255,255,0.1)]"
                            >
                              Voltar para a Agenda
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="flex items-center gap-4">
                <button onClick={() => setStep(1)} className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl"><ArrowLeft size={20} /></button>
                <h2 className="text-2xl font-bold tracking-tight">Escolha o Barbeiro</h2>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {barbers
                  .filter(barber => 
                    !selectedService?.barberIds || 
                    selectedService.barberIds.length === 0 || 
                    selectedService.barberIds.includes(barber.id)
                  )
                  .map(barber => (
                  <button
                    key={barber.id}
                    onClick={() => { setSelectedBarber(barber); setStep(3); }}
                    className={cn(
                      "p-6 rounded-3xl border text-left flex items-center justify-between transition-all active:scale-[0.98]",
                      selectedBarber?.id === barber.id ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-900 border-zinc-800 hover:border-zinc-700"
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden", selectedBarber?.id === barber.id ? "bg-zinc-950 text-zinc-100" : "bg-zinc-800 text-zinc-400")}>
                        {barber.photoUrl ? (
                          <img src={barber.photoUrl} alt={barber.name} className="w-full h-full object-cover" />
                        ) : (
                          <User size={24} />
                        )}
                      </div>
                      <h3 className="font-bold text-lg">{barber.name}</h3>
                    </div>
                    <ChevronRight size={20} className={cn(selectedBarber?.id === barber.id ? "text-zinc-950" : "text-zinc-700")} />
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="flex items-center gap-4">
                <button onClick={() => setStep(2)} className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl"><ArrowLeft size={20} /></button>
                <h2 className="text-2xl font-bold tracking-tight">Data e Horário</h2>
              </div>
              
              <div className="space-y-6">
                <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                  {[0, 1, 2, 3, 4, 5, 6].map(i => {
                    const date = startOfDay(new Date());
                    date.setDate(date.getDate() + i);
                    const isSelected = format(selectedDate, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd');
                    return (
                      <button
                        key={i}
                        onClick={() => setSelectedDate(date)}
                        className={cn(
                          "flex-shrink-0 w-20 py-4 rounded-2xl border flex flex-col items-center gap-1 transition-all",
                          isSelected ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-900 border-zinc-800 text-zinc-400"
                        )}
                      >
                        <span className="text-[10px] uppercase font-bold tracking-widest">{format(date, 'EEE', { locale: ptBR })}</span>
                        <span className="text-xl font-bold">{format(date, 'dd')}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {(() => {
                    const dayAvail = availability.filter(a => a.barberId === selectedBarber?.id && a.dayOfWeek === selectedDate.getDay());
                    if (dayAvail.length === 0) return <p className="col-span-full text-center text-zinc-500 py-4">Nenhum horário disponível para este dia.</p>;
                    
                    const slots: string[] = [];
                    const now = new Date();
                    dayAvail.forEach(avail => {
                      let current = parse(avail.startTime, 'HH:mm', selectedDate);
                      const end = parse(avail.endTime, 'HH:mm', selectedDate);
                      while (isBefore(current, end)) {
                        const slotTime = format(current, 'HH:mm');
                        const slotEnd = addMinutes(current, selectedService?.durationMinutes || 30);
                        
                        // Strict check: slot must be in the future
                        const isInPast = isBefore(current, now);

                        // Check if slot overlaps with any existing appointment
                        const isOccupied = appointments.some((app: any) => {
                          const appStart = app.startAt.toDate();
                          const appEnd = app.endAt.toDate();
                          // Overlap logic: s1 < e2 && s2 < e1
                          return isBefore(current, appEnd) && isBefore(appStart, slotEnd);
                        });

                        if (!isOccupied && !isInPast) {
                          slots.push(slotTime);
                        }
                        current = addMinutes(current, 30); // Increment by 30 mins for slot options
                      }
                    });

                    return slots.map(time => {
                      const [h, m] = time.split(':');
                      const timeDate = setMinutes(setHours(selectedDate, Number(h)), Number(m));
                      const isSelected = selectedTime && format(selectedTime, 'HH:mm') === time;
                      return (
                        <button
                          key={time}
                          onClick={() => { setSelectedTime(timeDate); setStep(4); }}
                          className={cn(
                            "py-4 rounded-2xl border font-bold transition-all",
                            isSelected ? "bg-zinc-100 border-zinc-100 text-zinc-950" : "bg-zinc-900 border-zinc-800 text-zinc-400"
                          )}
                        >
                          {time}
                        </button>
                      );
                    });
                  })()}
                </div>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="step4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="flex items-center gap-4">
                <button onClick={() => setStep(3)} className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl"><ArrowLeft size={20} /></button>
                <h2 className="text-2xl font-bold tracking-tight">Seus Dados</h2>
              </div>

              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl space-y-4 mb-6">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500">Serviço</span>
                  <span className="font-bold">{selectedService?.name}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500">Barbeiro</span>
                  <span className="font-bold">{selectedBarber?.name}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500">Data</span>
                  <span className="font-bold">{format(selectedTime!, "dd 'de' MMMM 'às' HH:mm", { locale: ptBR })}</span>
                </div>
                <div className="pt-4 border-t border-zinc-800 flex items-center justify-between">
                  <span className="font-bold">Total</span>
                  <span className="text-xl font-bold">{formatCurrency(selectedService?.price)}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">Seu Nome</label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={e => setClientName(e.target.value)}
                    placeholder="Como quer ser chamado?"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">Seu Telefone</label>
                  <input
                    type="tel"
                    required
                    value={clientPhone}
                    onChange={e => setClientPhone(e.target.value)}
                    placeholder="(00) 00000-0000"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <button
                onClick={handleBooking}
                disabled={bookingLoading || !clientName || !clientPhone}
                className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95 disabled:opacity-50 mt-8"
              >
                {bookingLoading ? <Loader2 className="animate-spin" /> : <>Confirmar Agendamento <CheckCircle2 size={20} /></>}
              </button>

              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  className="mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-500 text-sm"
                >
                  <AlertCircle size={18} />
                  <p>{error}</p>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
