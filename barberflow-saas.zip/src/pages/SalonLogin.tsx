import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import { Scissors, ArrowRight, Loader2, Phone, Lock } from 'lucide-react';

export default function SalonLogin() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) return;
    setLoading(true);
    setError('');

    const cleanPhone = phone.replace(/\D/g, '');

    try {
      const q = query(
        collection(db, 'salons'), 
        where('phone', '==', cleanPhone),
        where('password', '==', password)
      );
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        setError('Telefone ou senha incorretos.');
        setLoading(false);
        return;
      }

      const salonDoc = snapshot.docs[0];
      const salonData = salonDoc.data();

      // Simple session simulation
      localStorage.setItem('salonId', salonDoc.id);
      localStorage.setItem('salonName', salonData.name);
      
      navigate('/salon');
    } catch (err) {
      console.error('Login error:', err);
      setError('Erro ao entrar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-zinc-950 text-zinc-100">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full space-y-8"
      >
        <div className="text-center space-y-4">
          <img src="/logo.svg" alt="BarberFlow Logo" className="w-16 h-16 rounded-2xl mx-auto mb-6 shadow-xl" />
          <h1 className="text-3xl font-bold tracking-tight">Entrar no Salão</h1>
          <p className="text-zinc-400">Acesse o painel administrativo da sua barbearia.</p>
        </div>

        <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 p-8 rounded-[40px] space-y-6 shadow-2xl">
          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-2xl text-center">
              {error}
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 ml-1">Telefone</label>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <input
                type="tel"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="Ex: 11999999999"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 ml-1">Senha</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" /> : <>Entrar <ArrowRight size={20} /></>}
          </button>
        </form>

        <p className="text-center text-zinc-500 text-sm">
          Ainda não tem uma conta? <Link to="/register" className="text-zinc-100 font-bold hover:underline">Criar Salão</Link>
        </p>
      </motion.div>
    </div>
  );
}
