import { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { collection, addDoc, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import { Scissors, ArrowRight, Loader2, Phone, User, Lock, MapPin, Instagram, MessageCircle, Upload, CheckCircle2 } from 'lucide-react';
import { addDays } from 'date-fns';

export default function SalonRegister() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  
  // Salon Info
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [address, setAddress] = useState('');
  const [instagram, setInstagram] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [logo, setLogo] = useState<string | null>(null);
  
  // Owner Info
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [password, setPassword] = useState('');
  
  const [error, setError] = useState('');

  const generateSlug = (val: string) => {
    return val
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 300;
        canvas.height = 300;

        if (ctx) {
          // Center crop and resize
          const size = Math.min(img.width, img.height);
          const offsetX = (img.width - size) / 2;
          const offsetY = (img.height - size) / 2;
          ctx.drawImage(img, offsetX, offsetY, size, size, 0, 0, 300, 300);
          
          // Export as webp with 80% quality
          const dataUrl = canvas.toDataURL('image/webp', 0.8);
          setLogo(dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      if (!name || !slug || !address) {
        setError('Preencha os dados do salão.');
        return;
      }
      setStep(2);
      return;
    }

    if (!ownerName || !ownerPhone || !password) return;
    setLoading(true);
    setError('');

    const cleanPhone = ownerPhone.replace(/\D/g, '');
    const finalSlug = generateSlug(slug);

    try {
      // Check if phone already exists
      const qPhone = query(collection(db, 'salons'), where('phone', '==', cleanPhone));
      const snapPhone = await getDocs(qPhone);
      if (!snapPhone.empty) {
        setError('Este telefone já está cadastrado.');
        setLoading(false);
        return;
      }

      // Check if slug already exists
      const qSlug = query(collection(db, 'salons'), where('slug', '==', finalSlug));
      const snapSlug = await getDocs(qSlug);
      if (!snapSlug.empty) {
        setError('Este link (slug) já está em uso. Tente outro.');
        setLoading(false);
        return;
      }

      const now = new Date();
      const trialExpiresAt = addDays(now, 7);

      const docRef = await addDoc(collection(db, 'salons'), {
        name,
        slug: finalSlug,
        ownerName,
        ownerPhone: cleanPhone,
        phone: cleanPhone, // Keep for login compatibility
        password,
        address,
        instagram,
        whatsapp,
        logoUrl: logo,
        status: 'trial',
        createdAt: Timestamp.fromDate(now),
        trialExpiresAt: Timestamp.fromDate(trialExpiresAt),
        lastPaymentAt: null
      });

      localStorage.setItem('salonId', docRef.id);
      localStorage.setItem('salonName', name);
      navigate('/salon');
    } catch (err) {
      console.error('Register error:', err);
      setError('Erro ao cadastrar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-zinc-950 text-zinc-100">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-xl w-full space-y-8"
      >
        <div className="text-center space-y-4">
          <img src="/logo.svg" alt="BarberFlow Logo" className="w-16 h-16 rounded-2xl mx-auto mb-6 shadow-xl" />
          <h1 className="text-3xl font-bold tracking-tight">Crie seu Salão</h1>
          <p className="text-zinc-400">Passo {step} de 2: {step === 1 ? 'Dados da Barbearia' : 'Dados do Proprietário'}</p>
        </div>

        <form onSubmit={handleRegister} className="bg-zinc-900 border border-zinc-800 p-8 rounded-[40px] space-y-6 shadow-2xl">
          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-2xl text-center">
              {error}
            </div>
          )}
          
          {step === 1 ? (
            <div className="space-y-6">
              <div className="flex justify-center mb-6">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-32 h-32 bg-zinc-950 border-2 border-dashed border-zinc-800 rounded-3xl flex flex-col items-center justify-center cursor-pointer hover:border-zinc-100 transition-all overflow-hidden relative group"
                >
                  {logo ? (
                    <img src={logo} alt="Logo" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <Upload className="text-zinc-500 mb-2" size={24} />
                      <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Logo</span>
                    </>
                  )}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <Upload className="text-white" size={20} />
                  </div>
                </div>
                <input type="file" ref={fileInputRef} onChange={handleLogoChange} accept="image/*" className="hidden" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">Nome da Barbearia</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => {
                      setName(e.target.value);
                      if (!slug) setSlug(generateSlug(e.target.value));
                    }}
                    placeholder="Ex: Barber Shop Elite"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">Link (Slug)</label>
                  <input
                    type="text"
                    required
                    value={slug}
                    onChange={e => setSlug(generateSlug(e.target.value))}
                    placeholder="ex: barber-shop-elite"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Endereço Completo</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    placeholder="Rua, Número, Bairro, Cidade"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">Instagram (opcional)</label>
                  <div className="relative">
                    <Instagram className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                    <input
                      type="text"
                      value={instagram}
                      onChange={e => setInstagram(e.target.value)}
                      placeholder="@usuario"
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-zinc-400 ml-1">WhatsApp (opcional)</label>
                  <div className="relative">
                    <MessageCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                    <input
                      type="tel"
                      value={whatsapp}
                      onChange={e => setWhatsapp(e.target.value)}
                      placeholder="11999999999"
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95"
              >
                Próximo Passo <ArrowRight size={20} />
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Nome do Proprietário</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    type="text"
                    required
                    value={ownerName}
                    onChange={e => setOwnerName(e.target.value)}
                    placeholder="Seu nome completo"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Telefone (DDD + Número)</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    type="tel"
                    required
                    value={ownerPhone}
                    onChange={e => setOwnerPhone(e.target.value)}
                    placeholder="Ex: 11999999999"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-400 ml-1">Senha de Acesso</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 focus:outline-none focus:border-zinc-100 transition-colors"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex-1 bg-zinc-900 text-zinc-100 py-5 rounded-2xl font-bold hover:bg-zinc-800 transition-all active:scale-95"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-[2] bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="animate-spin" /> : <>Finalizar Cadastro <CheckCircle2 size={20} /></>}
                </button>
              </div>
            </div>
          )}
        </form>

        <p className="text-center text-zinc-500 text-sm">
          Já tem uma conta? <Link to="/login" className="text-zinc-100 font-bold hover:underline">Entrar</Link>
        </p>
      </motion.div>
    </div>
  );
}
