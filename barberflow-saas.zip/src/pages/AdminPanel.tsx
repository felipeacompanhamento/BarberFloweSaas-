import { useState, useEffect } from 'react';
import { useNavigate, Routes, Route, Link, useLocation } from 'react-router-dom';
import { collection, query, getDocs, updateDoc, doc, Timestamp, orderBy, where, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Users, 
  CreditCard, 
  LogOut, 
  Menu, 
  X, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Search,
  Loader2,
  Trash2,
  Edit2,
  Settings,
  ShieldCheck,
  Zap,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import ConfirmationModal from '../components/ConfirmationModal';

export default function AdminPanel() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Global Confirmation State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  useEffect(() => {
    if (!localStorage.getItem('adminId')) {
      navigate('/admin-login');
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('adminId');
    navigate('/admin-login');
  };

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-zinc-950 border-r border-zinc-900 p-6">
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
          <LayoutDashboard size={20} />
        </div>
        <h1 className="text-xl font-bold tracking-tight">SaaS Admin</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {[
          { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
          { path: '/admin/salons', label: 'Salões', icon: Users },
          { path: '/admin/payments', label: 'Pagamentos', icon: CreditCard },
          { path: '/admin/settings', label: 'Configurações', icon: Settings },
        ].map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all",
                isActive 
                  ? "bg-zinc-100 text-zinc-950" 
                  : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={handleLogout}
        className="flex items-center gap-3 px-4 py-3 rounded-2xl font-medium text-red-500 hover:bg-red-500/10 transition-all mt-auto"
      >
        <LogOut size={20} />
        Sair
      </button>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-zinc-950 text-zinc-100">
      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="lg:hidden fixed inset-y-0 left-0 w-72 z-[70]"
            >
              <Sidebar />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="hidden lg:block w-72 flex-shrink-0 sticky top-0 h-screen">
        <Sidebar />
      </div>

      <main className="flex-1 p-6 lg:p-10 overflow-auto">
        <div className="lg:hidden flex items-center justify-between mb-8">
          <h1 className="font-bold">SaaS Admin</h1>
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 bg-zinc-900 rounded-xl">
            <Menu size={24} />
          </button>
        </div>

        <Routes>
          <Route path="/" element={<AdminDashboard />} />
          <Route path="/salons" element={<AdminSalons onConfirm={setConfirmModal} />} />
          <Route path="/payments" element={<AdminPayments onConfirm={setConfirmModal} />} />
          <Route path="/settings" element={<AdminSettings />} />
        </Routes>

        <ConfirmationModal 
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          message={confirmModal.message}
        />
      </main>
    </div>
  );
}

function AdminDashboard() {
  const [stats, setStats] = useState({ totalSalons: 0, activeSalons: 0, trialSalons: 0, totalRevenue: 0, monthlyRevenue: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const salonsSnap = await getDocs(collection(db, 'salons'));
        const salons = salonsSnap.docs.map(d => d.data());
        
        const paymentsSnap = await getDocs(query(collection(db, 'payments'), where('status', '==', 'paid')));
        const revenue = paymentsSnap.docs.reduce((acc, d) => acc + d.data().amount, 0);

        // Monthly revenue (last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const monthlyRevenue = paymentsSnap.docs
          .filter(d => d.data().paidAt?.toDate() > thirtyDaysAgo)
          .reduce((acc, d) => acc + d.data().amount, 0);

        setStats({
          totalSalons: salons.length,
          activeSalons: salons.filter(s => s.status === 'active').length,
          trialSalons: salons.filter(s => s.status === 'trial').length,
          totalRevenue: revenue,
          monthlyRevenue: monthlyRevenue
        });
      } catch (err) {
        console.error('Error fetching admin stats:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-10">
      <div className="flex flex-col gap-2">
        <h2 className="text-4xl font-black tracking-tight text-white">Dashboard <span className="text-zinc-500 font-medium text-lg ml-2">SaaS Overview</span></h2>
        <p className="text-zinc-400">Gerencie sua plataforma e acompanhe o crescimento.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total de Salões', value: stats.totalSalons, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10', trend: '+12%' },
          { label: 'Salões Ativos', value: stats.activeSalons, icon: ShieldCheck, color: 'text-emerald-400', bg: 'bg-emerald-500/10', trend: 'Ativos' },
          { label: 'MRR (Mensal)', value: formatCurrency(stats.monthlyRevenue), icon: Zap, color: 'text-amber-400', bg: 'bg-amber-500/10', trend: 'Recorrência' },
          { label: 'Receita Total', value: formatCurrency(stats.totalRevenue), icon: TrendingUp, color: 'text-purple-400', bg: 'bg-purple-500/10', trend: 'Acumulado' },
        ].map((stat, i) => (
          <motion.div 
            key={i} 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-zinc-900/50 backdrop-blur-xl border border-zinc-800 p-8 rounded-[32px] hover:border-zinc-700 transition-all group"
          >
            <div className="flex items-start justify-between mb-6">
              <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110", stat.bg, stat.color)}>
                <stat.icon size={28} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest px-3 py-1 bg-zinc-800 rounded-full text-zinc-400">{stat.trend}</span>
            </div>
            <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
            <h3 className="text-3xl font-black mt-2 tracking-tight">{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-8">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <TrendingUp size={20} className="text-emerald-400" />
            Crescimento da Plataforma
          </h3>
          <div className="h-64 flex items-end justify-between gap-2 px-4">
            {[40, 65, 45, 90, 75, 85, 100].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-4 group">
                <div className="w-full bg-zinc-800 rounded-t-xl relative overflow-hidden" style={{ height: `${h}%` }}>
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height: '100%' }}
                    transition={{ delay: 0.5 + (i * 0.1) }}
                    className="absolute inset-0 bg-gradient-to-t from-emerald-500/20 to-emerald-500/40" 
                  />
                </div>
                <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-tighter">Dia {i + 1}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-8">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <ShieldCheck size={20} className="text-blue-400" />
            Status dos Salões
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Ativos', value: stats.activeSalons, total: stats.totalSalons, color: 'bg-emerald-500' },
              { label: 'Trial', value: stats.trialSalons, total: stats.totalSalons, color: 'bg-amber-500' },
              { label: 'Bloqueados', value: stats.totalSalons - stats.activeSalons - stats.trialSalons, total: stats.totalSalons, color: 'bg-red-500' },
            ].map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-400 font-medium">{item.label}</span>
                  <span className="font-bold">{item.value}</span>
                </div>
                <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(item.value / item.total) * 100}%` }}
                    className={cn("h-full", item.color)} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [config, setConfig] = useState({ mercadopagoAccessToken: '', mercadopagoPublicKey: '', subscriptionPrice: 49.90 });

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await fetch('/api/admin/config');
        const data = await res.json();
        setConfig(prev => ({
          ...prev,
          ...data
        }));
      } catch (err) {
        console.error('Error fetching config:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchConfig();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (res.ok) {
        // Re-fetch to get the masked tokens from server
        const refreshRes = await fetch('/api/admin/config');
        const refreshedData = await refreshRes.json();
        setConfig(prev => ({ ...prev, ...refreshedData }));
        alert('Configurações salvas com sucesso!');
      } else {
        const errorData = await res.json();
        alert(`Erro ao salvar: ${errorData.details || errorData.error || 'Erro desconhecido'}`);
      }
    } catch (err) {
      console.error('Error saving config:', err);
      alert('Erro de conexão ao salvar configurações.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="max-w-2xl space-y-10">
      <div className="flex flex-col gap-2">
        <h2 className="text-4xl font-black tracking-tight text-white">Configurações <span className="text-zinc-500 font-medium text-lg ml-2">SaaS Engine</span></h2>
        <p className="text-zinc-400">Configure as chaves da plataforma e valores de assinatura.</p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-[40px] p-10 space-y-8">
          <div className="flex items-center gap-4 mb-2">
            <div className="w-12 h-12 bg-blue-500/10 text-blue-400 rounded-2xl flex items-center justify-center">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h3 className="font-bold text-lg">Mercado Pago</h3>
              <p className="text-xs text-zinc-500">Integração para pagamentos via PIX.</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Public Key</label>
              <input 
                type="text"
                value={config.mercadopagoPublicKey} 
                onChange={e => setConfig({ ...config, mercadopagoPublicKey: e.target.value })}
                placeholder="APP_USR-..."
                className={cn(
                  "w-full bg-zinc-950 border rounded-2xl p-4 text-sm focus:ring-2 focus:ring-blue-500 transition-all",
                  config.mercadopagoPublicKey.includes('...') ? "border-amber-500/50" : "border-zinc-800"
                )} 
              />
              {config.mercadopagoPublicKey.includes('...') && (
                <p className="text-[10px] text-amber-500 font-bold uppercase tracking-widest mt-1">Chave Mascarada: Para alterar, apague e cole a nova chave.</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Access Token</label>
              <input 
                type="password"
                value={config.mercadopagoAccessToken} 
                onChange={e => setConfig({ ...config, mercadopagoAccessToken: e.target.value })}
                placeholder="APP_USR-..."
                className={cn(
                  "w-full bg-zinc-950 border rounded-2xl p-4 text-sm focus:ring-2 focus:ring-blue-500 transition-all",
                  config.mercadopagoAccessToken.includes('...') ? "border-amber-500/50" : "border-zinc-800"
                )} 
              />
              {config.mercadopagoAccessToken.includes('...') && (
                <p className="text-[10px] text-amber-500 font-bold uppercase tracking-widest mt-1">Token Mascarado: Para alterar, apague e cole o novo token.</p>
              )}
              <p className="text-[10px] text-zinc-600 italic">O token será mascarado após salvar para sua segurança.</p>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Valor da Assinatura (Mensal)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-bold">R$</span>
                <input 
                  type="number" 
                  step="0.01"
                  value={config.subscriptionPrice} 
                  onChange={e => setConfig({ ...config, subscriptionPrice: Number(e.target.value) })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 pl-12 text-sm focus:ring-2 focus:ring-blue-500 transition-all font-bold" 
                />
              </div>
            </div>
          </div>
        </div>

        <button 
          disabled={saving}
          className="w-full py-6 bg-zinc-100 text-zinc-950 rounded-[24px] font-black text-sm uppercase tracking-widest hover:bg-white transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {saving ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
          Salvar Configurações
        </button>
      </form>
    </div>
  );
}

function AdminSalons({ onConfirm }: { onConfirm: any }) {
  const [salons, setSalons] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSalon, setEditingSalon] = useState<any>(null);
  
  // Edit state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [slug, setSlug] = useState('');

  const fetchSalons = async () => {
    try {
      const q = query(collection(db, 'salons'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      setSalons(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error('Error fetching salons:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSalons();
  }, []);

  const updateStatus = async (id: string, status: string) => {
    await updateDoc(doc(db, 'salons', id), { status });
    setSalons(prev => prev.map(s => s.id === id ? { ...s, status } : s));
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Salão',
      message: 'Tem certeza que deseja excluir este salão? Todos os dados vinculados (barbeiros, serviços, agendamentos) serão perdidos.',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'salons', id));
          setSalons(prev => prev.filter(s => s.id !== id));
        } catch (err) {
          console.error('Error deleting salon:', err);
        }
      }
    });
  };

  const openEdit = (salon: any) => {
    setEditingSalon(salon);
    setName(salon.name);
    setPhone(salon.phone);
    setSlug(salon.slug);
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!editingSalon) return;
    try {
      await updateDoc(doc(db, 'salons', editingSalon.id), {
        name,
        phone,
        slug: slug.toLowerCase().replace(/\s+/g, '-')
      });
      setSalons(prev => prev.map(s => s.id === editingSalon.id ? { ...s, name, phone, slug } : s));
      setIsModalOpen(false);
    } catch (err) {
      console.error('Error updating salon:', err);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Gerenciar Salões</h2>
      <div className="grid grid-cols-1 gap-4">
        {salons.map(salon => (
          <div key={salon.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <h3 className="text-xl font-bold">{salon.name}</h3>
              <p className="text-sm text-zinc-400 flex items-center gap-2">
                <Users size={14} /> {salon.phone}
              </p>
              <p className="text-xs text-zinc-500">
                Criado em: {format(salon.createdAt.toDate(), 'dd/MM/yyyy')}
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider",
                salon.status === 'active' ? "bg-green-500/10 text-green-500" :
                salon.status === 'trial' ? "bg-orange-500/10 text-orange-500" :
                "bg-red-500/10 text-red-500"
              )}>
                {salon.status}
              </div>
              
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => openEdit(salon)}
                  className="p-2 bg-zinc-800 text-zinc-400 hover:text-zinc-100 rounded-xl"
                  title="Editar"
                >
                  <Edit2 size={20} />
                </button>
                <button 
                  onClick={() => updateStatus(salon.id, 'active')}
                  className="p-2 bg-zinc-800 text-zinc-400 hover:text-green-500 rounded-xl"
                  title="Ativar"
                >
                  <CheckCircle2 size={20} />
                </button>
                <button 
                  onClick={() => updateStatus(salon.id, 'blocked')}
                  className="p-2 bg-zinc-800 text-zinc-400 hover:text-red-500 rounded-xl"
                  title="Bloquear"
                >
                  <XCircle size={20} />
                </button>
                <button 
                  onClick={() => handleDelete(salon.id)}
                  className="p-2 bg-zinc-800 text-zinc-400 hover:text-red-500 rounded-xl"
                  title="Excluir"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsModalOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="relative bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-6">
              <h3 className="text-xl font-bold">Editar Salão</h3>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Nome do Salão</label>
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Telefone</label>
                  <input value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase">Slug (URL)</label>
                  <input value={slug} onChange={e => setSlug(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm" />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl font-bold text-sm">Cancelar</button>
                <button onClick={handleSave} className="flex-1 py-4 bg-zinc-100 text-zinc-950 rounded-2xl font-bold text-sm">Salvar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AdminPayments({ onConfirm }: { onConfirm: any }) {
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPayments = async () => {
    try {
      const q = query(collection(db, 'payments'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      setPayments(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error('Error fetching payments:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  const confirmPayment = async (pay: any) => {
    await updateDoc(doc(db, 'payments', pay.id), { status: 'paid' });
    await updateDoc(doc(db, 'salons', pay.salonId), { 
      status: 'active',
      lastPaymentAt: Timestamp.now()
    });
    setPayments(prev => prev.map(p => p.id === pay.id ? { ...p, status: 'paid' } : p));
  };

  const handleDelete = async (id: string) => {
    onConfirm({
      isOpen: true,
      title: 'Excluir Pagamento',
      message: 'Tem certeza que deseja excluir este registro de pagamento?',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'payments', id));
          setPayments(prev => prev.filter(p => p.id !== id));
        } catch (err) {
          console.error('Error deleting payment:', err);
        }
      }
    });
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Pagamentos</h2>
      <div className="grid grid-cols-1 gap-4">
        {payments.map(pay => (
          <div key={pay.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <h3 className="text-lg font-bold">{formatCurrency(pay.amount)}</h3>
              <p className="text-sm text-zinc-400">Salão ID: {pay.salonId}</p>
              <p className="text-xs text-zinc-500">
                {format(pay.createdAt.toDate(), 'dd/MM/yyyy HH:mm')}
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <span className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider",
                pay.status === 'paid' ? "bg-green-500/10 text-green-500" : "bg-orange-500/10 text-orange-500"
              )}>
                {pay.status === 'paid' ? 'Pago' : 'Pendente'}
              </span>
              
              {pay.status === 'pending' && (
                <button 
                  onClick={() => confirmPayment(pay)}
                  className="bg-zinc-100 text-zinc-950 px-6 py-2 rounded-xl font-bold text-sm hover:bg-zinc-200"
                >
                  Confirmar Pix
                </button>
              )}
              <button 
                onClick={() => handleDelete(pay.id)}
                className="p-2 bg-zinc-800 text-zinc-400 hover:text-red-500 rounded-xl"
                title="Excluir"
              >
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}


