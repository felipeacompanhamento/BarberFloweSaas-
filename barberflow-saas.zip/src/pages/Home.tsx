import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors, Calendar, Search, ChevronRight, Instagram, MapPin, Phone } from 'lucide-react';
import BookingForm from '../components/BookingForm';
import ClientAppointments from '../components/ClientAppointments';

export default function Home() {
  const [view, setView] = useState<'home' | 'booking' | 'appointments'>('home');

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="p-6 flex items-center justify-between border-b border-zinc-900 sticky top-0 bg-zinc-950/80 backdrop-blur-xl z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-zinc-100 text-zinc-950 rounded-xl flex items-center justify-center">
            <Scissors size={20} />
          </div>
          <h1 className="text-xl font-bold tracking-tight">BarberFlow</h1>
        </div>
        <button 
          onClick={() => setView('appointments')}
          className="w-10 h-10 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-center hover:border-zinc-700 transition-colors"
        >
          <Search size={20} />
        </button>
      </header>

      <main className="flex-1">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-6 space-y-8"
            >
              {/* Hero Section */}
              <section className="relative h-64 rounded-3xl overflow-hidden group">
                <img 
                  src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&q=80&w=1000" 
                  alt="Barber Shop" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent flex flex-col justify-end p-6">
                  <h2 className="text-3xl font-bold mb-2">Estilo & Confiança</h2>
                  <p className="text-zinc-300 text-sm max-w-xs">Agende seu horário com os melhores profissionais da região.</p>
                </div>
              </section>

              {/* Main Actions */}
              <div className="grid grid-cols-1 gap-4">
                <button 
                  onClick={() => setView('booking')}
                  className="bg-zinc-100 text-zinc-950 p-6 rounded-3xl flex items-center justify-between group transition-all active:scale-95"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-zinc-950 text-zinc-100 rounded-2xl flex items-center justify-center">
                      <Calendar size={24} />
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-lg">Novo Agendamento</p>
                      <p className="text-sm opacity-60">Escolha data e hora agora</p>
                    </div>
                  </div>
                  <ChevronRight size={24} className="group-hover:translate-x-1 transition-transform" />
                </button>

                <button 
                  onClick={() => setView('appointments')}
                  className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex items-center justify-between group transition-all active:scale-95"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-zinc-800 text-zinc-100 rounded-2xl flex items-center justify-center">
                      <Search size={24} />
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-lg">Meus Horários</p>
                      <p className="text-sm text-zinc-400">Consulte seus agendamentos</p>
                    </div>
                  </div>
                  <ChevronRight size={24} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* Info Section */}
              <section className="space-y-4 pt-4">
                <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500">Informações</h3>
                <div className="grid grid-cols-1 gap-3">
                  <div className="flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800/50 rounded-2xl">
                    <MapPin size={20} className="text-zinc-500" />
                    <p className="text-sm">Rua das Barbearias, 123 - Centro</p>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800/50 rounded-2xl">
                    <Phone size={20} className="text-zinc-500" />
                    <p className="text-sm">(11) 99999-9999</p>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800/50 rounded-2xl">
                    <Instagram size={20} className="text-zinc-500" />
                    <p className="text-sm">@barberflow_oficial</p>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {view === 'booking' && (
            <motion.div
              key="booking"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <BookingForm onComplete={() => setView('home')} />
            </motion.div>
          )}

          {view === 'appointments' && (
            <motion.div
              key="appointments"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <ClientAppointments onBack={() => setView('home')} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="p-8 text-center text-zinc-600 text-xs border-t border-zinc-900">
        <p>© 2026 BarberFlow. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
