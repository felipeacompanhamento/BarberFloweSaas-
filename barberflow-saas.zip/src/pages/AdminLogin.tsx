import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import { Shield, ArrowRight, Loader2 } from 'lucide-react';

export default function AdminLogin() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) return;
    setLoading(true);
    setError('');

    const cleanPhone = phone.replace(/\D/g, '');

    try {
      const q = query(
        collection(db, 'admins'), 
        where('phone', '==', cleanPhone),
        where('password', '==', password)
      );
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        setError('Acesso negado.');
        setLoading(false);
        return;
      }

      const adminDoc = snapshot.docs[0];
      
      // Simple session simulation
      localStorage.setItem('adminId', adminDoc.id);
      
      navigate('/admin');
    } catch (err) {
      console.error('Admin login error:', err);
      setError('Erro ao entrar.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-zinc-950 text-zinc-100">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-zinc-100 text-zinc-950 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Shield size={32} />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Painel SaaS</h1>
          <p className="text-zinc-400">Acesso restrito ao administrador da plataforma.</p>
        </div>

        <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 p-8 rounded-[40px] space-y-6 shadow-2xl">
          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-2xl text-center">
              {error}
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 ml-1">Telefone Admin</label>
            <input
              type="tel"
              required
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="Ex: 11999999999"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 ml-1">Senha Mestra</label>
            <input
              type="password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 focus:outline-none focus:border-zinc-100 transition-colors"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-zinc-100 text-zinc-950 py-5 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" /> : <>Acessar Plataforma <ArrowRight size={20} /></>}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
