import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, query, where, getDocs, Timestamp, doc, updateDoc, getDoc } from "firebase/firestore";
import { initializeApp as initializeAdminApp, cert, getApps } from "firebase-admin/app";
import { getMessaging } from "firebase-admin/messaging";
import { getFirestore as getAdminFirestore } from "firebase-admin/firestore";
import cron from "node-cron";
import { addMinutes, subMinutes, subHours, subDays, isBefore, isAfter } from "date-fns";
import { MercadoPagoConfig, Payment } from 'mercadopago';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load Firebase Client Config (for social previews and database ID)
const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
let firebaseConfig: any = null;
if (fs.existsSync(configPath)) {
  firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
}

// Initialize Firebase Admin
let serviceAccount: any = null;
try {
  if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
  }
} catch (e) {
  console.error("Error parsing FIREBASE_SERVICE_ACCOUNT:", e);
}

if (serviceAccount) {
  try {
    initializeAdminApp({
      credential: cert(serviceAccount),
      projectId: firebaseConfig?.projectId
    });
    console.log("Firebase Admin initialized successfully");
  } catch (e) {
    console.error("Error initializing Firebase Admin:", e);
  }
} else {
  console.warn("FIREBASE_SERVICE_ACCOUNT not found or invalid. Push notifications will not be sent.");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  let db: any;
  if (firebaseConfig) {
    const firebaseApp = initializeApp(firebaseConfig);
    db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
  }

  const databaseId = firebaseConfig?.firestoreDatabaseId || '(default)';

  app.use(express.json());

  // --- Mercado Pago & SaaS Routes ---

  // Admin Config
  app.post("/api/admin/config", async (req, res) => {
    const { mercadopagoAccessToken, mercadopagoPublicKey, subscriptionPrice } = req.body;
    console.log("[AdminConfig] Received save request:", { 
      hasToken: !!mercadopagoAccessToken, 
      hasPublicKey: !!mercadopagoPublicKey, 
      subscriptionPrice 
    });

    try {
      const configRef = getAdminFirestore(databaseId).collection('config').doc('mercadopago');
      const doc = await configRef.get();
      
      const updateData: any = {
        subscriptionPrice: Number(subscriptionPrice) || 0,
        updatedAt: new Date()
      };

      // Only update token if it's provided and NOT masked (doesn't contain "...")
      if (mercadopagoAccessToken && !mercadopagoAccessToken.includes('...')) {
        updateData.mercadopagoAccessToken = mercadopagoAccessToken.trim();
        console.log("[AdminConfig] Updating Access Token");
      }

      if (mercadopagoPublicKey && !mercadopagoPublicKey.includes('...')) {
        updateData.mercadopagoPublicKey = mercadopagoPublicKey.trim();
        console.log("[AdminConfig] Updating Public Key");
      }

      if (doc.exists) {
        await configRef.update(updateData);
        console.log("[AdminConfig] Document updated");
      } else {
        await configRef.set(updateData);
        console.log("[AdminConfig] Document created");
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("[AdminConfig] Error saving config:", error);
      res.status(500).json({ error: "Failed to save config", details: error instanceof Error ? error.message : String(error) });
    }
  });

  // Verify Payment Status (Manual)
  app.get("/api/payments/verify/:paymentId", async (req, res) => {
    const { paymentId } = req.params;
    try {
      const payDoc = await getAdminFirestore(databaseId).collection('payments').doc(paymentId).get();
      if (!payDoc.exists) return res.status(404).json({ error: "Pagamento não encontrado" });
      
      const payData = payDoc.data() as any;
      if (payData.status === 'paid') return res.json({ status: 'paid' });

      const configDoc = await getAdminFirestore(databaseId).collection('config').doc('mercadopago').get();
      const { mercadopagoAccessToken } = configDoc.data() as any;
      
      const client = new MercadoPagoConfig({ accessToken: mercadopagoAccessToken });
      const payment = new Payment(client);
      
      const mpPayment = await payment.get({ id: payData.mpPaymentId });
      
      if (mpPayment.status === "approved") {
        await payDoc.ref.update({ status: 'paid', paidAt: new Date() });
        
        // Update salon status and extend expiration
        const salonRef = getAdminFirestore(databaseId).collection('salons').doc(payData.salonId);
        const salonDoc = await salonRef.get();
        const salonData = salonDoc.data() as any;
        
        let currentExpiry = salonData.trialExpiresAt?.toDate() || new Date();
        if (currentExpiry < new Date()) currentExpiry = new Date();
        
        const newExpiry = addMinutes(currentExpiry, 30 * 24 * 60); // 30 days
        
        await salonRef.update({
          status: 'active',
          lastPaymentAt: new Date(),
          trialExpiresAt: newExpiry
        });
        
        return res.json({ status: 'paid', newExpiry });
      }
      
      res.json({ status: mpPayment.status });
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ error: "Failed to verify payment" });
    }
  });

  app.get("/api/admin/config", async (req, res) => {
    try {
      const doc = await getAdminFirestore(databaseId).collection('config').doc('mercadopago').get();
      if (!doc.exists) return res.json({ mercadopagoAccessToken: '', mercadopagoPublicKey: '', subscriptionPrice: 49.90 });
      
      const data = doc.data() as any;
      const result = { ...data };

      // Mask tokens for security
      if (result.mercadopagoAccessToken && result.mercadopagoAccessToken.length > 15) {
        result.mercadopagoAccessToken = result.mercadopagoAccessToken.substring(0, 10) + "..." + result.mercadopagoAccessToken.substring(result.mercadopagoAccessToken.length - 4);
      }
      if (result.mercadopagoPublicKey && result.mercadopagoPublicKey.length > 15) {
        result.mercadopagoPublicKey = result.mercadopagoPublicKey.substring(0, 10) + "..." + result.mercadopagoPublicKey.substring(result.mercadopagoPublicKey.length - 4);
      }
      
      res.json(result);
    } catch (error) {
      console.error("[AdminConfig] Error fetching config:", error);
      res.status(500).json({ error: "Failed to fetch config" });
    }
  });

  // Create PIX Payment
  app.post("/api/payments/create-pix", async (req, res) => {
    const { salonId, email } = req.body;
    
    try {
      if (!salonId) return res.status(400).json({ error: "Salon ID is required" });

      const configDoc = await getAdminFirestore(databaseId).collection('config').doc('mercadopago').get();
      if (!configDoc.exists) return res.status(400).json({ error: "Mercado Pago não configurado no painel Admin." });
      
      const configData = configDoc.data() as any;
      const token = configData.mercadopagoAccessToken?.trim();
      const price = Number(configData.subscriptionPrice) || 49.90;

      if (!token || token.includes('...')) {
        return res.status(400).json({ error: "Token do Mercado Pago inválido ou mascarado. Por favor, reconfigure no painel Admin." });
      }

      const salonDoc = await getAdminFirestore(databaseId).collection('salons').doc(salonId).get();
      if (!salonDoc.exists) return res.status(404).json({ error: "Salão não encontrado." });
      const salonData = salonDoc.data() as any;

      const client = new MercadoPagoConfig({ accessToken: token });
      const payment = new Payment(client);

      const body: any = {
        transaction_amount: price < 1 ? 1.00 : price, // MP requires at least 1.00 for some accounts
        description: `Assinatura BarberFlow - ${salonData.name}`,
        payment_method_id: 'pix',
        external_reference: salonId,
        payer: {
          email: email || 'cliente@barberflow.com',
          first_name: salonData.ownerName?.split(' ')[0] || 'Dono',
          last_name: salonData.ownerName?.split(' ').slice(1).join(' ') || 'Salão',
          identification: {
            type: 'CPF',
            number: '00000000000' // Placeholder, some accounts require this
          }
        }
      };

      // Only add notification_url if we are not in a local environment
      const host = req.get('host');
      if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
        body.notification_url = `${process.env.APP_URL || 'https://' + host}/api/webhooks/mercadopago`;
      }

      console.log(`[PIX] Creating payment for salon ${salonId} (${salonData.name}) - Amount: ${body.transaction_amount}`);
      
      const result = await payment.create({ 
        body,
        requestOptions: {
          idempotencyKey: crypto.randomUUID()
        }
      });

      console.log(`[PIX] Payment created successfully. ID: ${result.id}`);

      // Save payment to Firestore
      const paymentData = {
        salonId,
        amount: body.transaction_amount,
        status: 'pending',
        createdAt: new Date(),
        mpPaymentId: result.id?.toString(),
        qrCode: result.point_of_interaction?.transaction_data?.qr_code,
        qrCodeBase64: result.point_of_interaction?.transaction_data?.qr_code_base64,
        externalReference: result.external_reference || salonId
      };

      const payRef = await getAdminFirestore(databaseId).collection('payments').add(paymentData);

      res.json({ 
        id: payRef.id,
        ...paymentData
      });
    } catch (error: any) {
      console.error("Error creating PIX:", error);
      
      let errorMessage = "Erro ao processar pagamento com Mercado Pago.";
      let mpDetails = null;

      if (error.response) {
        const mpError = error.response.data || error.response;
        console.error("Mercado Pago API Error:", JSON.stringify(mpError, null, 2));
        mpDetails = mpError;
        
        if (mpError.message) errorMessage = mpError.message;
        if (mpError.cause && Array.isArray(mpError.cause) && mpError.cause[0]?.description) {
          errorMessage = mpError.cause[0].description;
        }
      } else {
        errorMessage = error.message || errorMessage;
      }

      res.status(500).json({ 
        error: "Failed to create PIX payment",
        details: errorMessage,
        mpError: mpDetails
      });
    }
  });

  // Webhook
  app.post("/api/webhooks/mercadopago", async (req, res) => {
    const { action, data } = req.body;
    console.log("[Webhook] Mercado Pago:", action, data);

    if (action === "payment.updated" || action === "payment.created") {
      try {
        const paymentId = data.id;
        const configDoc = await getAdminFirestore(databaseId).collection('config').doc('mercadopago').get();
        const { mercadopagoAccessToken } = configDoc.data() as any;
        
        const client = new MercadoPagoConfig({ accessToken: mercadopagoAccessToken });
        const payment = new Payment(client);
        
        const mpPayment = await payment.get({ id: paymentId });
        
        if (mpPayment.status === "approved") {
          // Find our payment record
          const paymentsSnap = await getAdminFirestore(databaseId)
            .collection('payments')
            .where('mpPaymentId', '==', paymentId.toString())
            .limit(1)
            .get();

          if (!paymentsSnap.empty) {
            const payDoc = paymentsSnap.docs[0];
            const payData = payDoc.data();

            if (payData.status !== 'paid') {
              await payDoc.ref.update({ status: 'paid', paidAt: new Date() });
              
              // Update salon status and extend expiration
              const salonRef = getAdminFirestore(databaseId).collection('salons').doc(payData.salonId);
              const salonDoc = await salonRef.get();
              const salonData = salonDoc.data() as any;
              
              let currentExpiry = salonData.trialExpiresAt?.toDate() || new Date();
              if (currentExpiry < new Date()) currentExpiry = new Date();
              
              const newExpiry = addMinutes(currentExpiry, 30 * 24 * 60); // 30 days
              
              await salonRef.update({
                status: 'active',
                lastPaymentAt: new Date(),
                trialExpiresAt: newExpiry
              });
              console.log(`[Webhook] Salon ${payData.salonId} activated and extended until ${newExpiry}`);
            }
          }
        }
      } catch (error) {
        console.error("[Webhook] Error processing payment:", error);
      }
    }
    res.status(200).send("OK");
  });

  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });

  // --- Notification Logic ---
  const sendPushNotification = async (identifier: string, title: string, body: string, icon?: string) => {
    if (getApps().length === 0) return;

    try {
      // Get user's FCM token from Firestore using phone number
      const tokenDoc = await getAdminFirestore(databaseId).collection('fcm_tokens').doc(identifier.replace(/\D/g, '')).get();
      if (!tokenDoc.exists) return;

      const { token } = tokenDoc.data() as any;
      if (!token) return;

      await getMessaging().send({
        token,
        notification: { title, body },
        android: { 
          notification: { 
            icon: 'stock_ticker_update', 
            color: '#09090b',
            imageUrl: icon 
          } 
        },
        apns: {
          payload: {
            aps: {
              'mutable-content': 1
            },
            fcm_options: {
              image: icon
            }
          }
        }
      });
      console.log(`[Notification] Sent to ${identifier}: ${title}`);
    } catch (error) {
      console.error(`[Notification] Error sending to ${identifier}:`, error);
    }
  };

  // Cron job to check for notifications every minute
  cron.schedule('* * * * *', async () => {
    if (getApps().length === 0) return;
    console.log("[Cron] Checking for notifications in database:", databaseId);

    try {
      const appointmentsSnap = await getAdminFirestore(databaseId)
        .collectionGroup('appointments')
        .where('status', '==', 'scheduled')
        .get();

      const now = new Date();
      for (const apptDoc of appointmentsSnap.docs) {
        try {
          const appt = { id: apptDoc.id, ...apptDoc.data() } as any;
          const startAt = appt.startAt.toDate();
          const notified = appt.notified || {};
          const clientPhone = appt.clientPhone;
          const salonId = appt.salonId || apptDoc.ref.parent.parent?.id;

          if (!clientPhone || !salonId) continue;

          // 1. Immediate (Created)
          if (!notified.created) {
            const salonDoc = await getAdminFirestore(databaseId).collection('salons').doc(salonId).get();
            const salon = salonDoc.data() as any;
            await sendPushNotification(
              clientPhone, 
              "Agendamento Confirmado!", 
              `Seu horário na ${salon?.name || 'Barbearia'} foi marcado para ${startAt.toLocaleString('pt-BR')}.`,
              salon?.logoUrl
            );
            await apptDoc.ref.update({ 'notified.created': true });
          }

          // 2. One day before
          if (!notified.dayBefore && isBefore(subDays(startAt, 1), now) && isAfter(startAt, now)) {
            const salonDoc = await getAdminFirestore(databaseId).collection('salons').doc(salonId).get();
            const salon = salonDoc.data() as any;
            await sendPushNotification(
              clientPhone,
              "Lembrete: Seu agendamento é amanhã!",
              `Não esqueça seu horário na ${salon?.name || 'Barbearia'} amanhã às ${startAt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.`,
              salon?.logoUrl
            );
            await apptDoc.ref.update({ 'notified.dayBefore': true });
          }

          // 3. 4 hours before
          if (!notified.fourHoursBefore && isBefore(subHours(startAt, 4), now) && isAfter(startAt, now)) {
            const salonDoc = await getAdminFirestore(databaseId).collection('salons').doc(salonId).get();
            const salon = salonDoc.data() as any;
            await sendPushNotification(
              clientPhone,
              "Faltam 4 horas!",
              `Seu agendamento na ${salon?.name || 'Barbearia'} é hoje às ${startAt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.`,
              salon?.logoUrl
            );
            await apptDoc.ref.update({ 'notified.fourHoursBefore': true });
          }

          // 4. 30 minutes before
          if (!notified.thirtyMinutesBefore && isBefore(subMinutes(startAt, 30), now) && isAfter(startAt, now)) {
            const salonDoc = await getAdminFirestore(databaseId).collection('salons').doc(salonId).get();
            const salon = salonDoc.data() as any;
            await sendPushNotification(
              clientPhone,
              "Está quase na hora!",
              `Seu agendamento na ${salon?.name || 'Barbearia'} começa em 30 minutos.`,
              salon?.logoUrl
            );
            await apptDoc.ref.update({ 'notified.thirtyMinutesBefore': true });
          }
        } catch (itemError) {
          console.error(`[Cron] Error processing appointment ${apptDoc.id}:`, itemError);
        }
      }
    } catch (cronError) {
      console.error("[Cron] Fatal error in notification job:", cronError);
    }
  });

  // --- Routes ---
  app.get("/book/:slug", async (req, res, next) => {
    const { slug } = req.params;
    const url = req.originalUrl;

    try {
      let template = fs.readFileSync(path.join(process.cwd(), "index.html"), "utf-8");
      template = await vite.transformIndexHtml(url, template);

      let title = "BarberFlow - Agendamento Inteligente";
      let description = "A agenda da sua barbearia no piloto automático.";
      let image = "/logo.svg";

      if (db) {
        const salonSnap = await getDocs(query(collection(db, 'salons'), where('slug', '==', slug)));
        if (!salonSnap.empty) {
          const salonData = salonSnap.docs[0].data();
          title = salonData.name;
          description = `Agende seu horário na ${salonData.name} pelo BarberFlow.`;
          if (salonData.logoUrl) image = salonData.logoUrl;
        }
      }

      const metaTags = `
        <title>${title}</title>
        <meta name="description" content="${description}" />
        <meta property="og:title" content="${title}" />
        <meta property="og:description" content="${description}" />
        <meta property="og:image" content="${image}" />
        <meta property="og:url" content="${process.env.APP_URL || ''}${url}" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="${title}" />
        <meta name="twitter:description" content="${description}" />
        <meta name="twitter:image" content="${image}" />
      `;

      const html = template
        .replace(/<title>.*?<\/title>/, metaTags)
        .replace(/<meta name="description".*?\/>/, "");

      res.status(200).set({ "Content-Type": "text/html" }).end(html);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });

  app.use(vite.middlewares);

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] BarberFlow is ready and listening on port ${PORT}`);
  });
}

startServer();
