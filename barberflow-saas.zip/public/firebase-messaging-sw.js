importScripts('https://www.gstatic.com/firebasejs/10.7.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.0/firebase-messaging-compat.js');

// These values are injected from the main app or hardcoded if needed
// For the SW, we often need to hardcode or use a specific config
firebase.initializeApp({
  apiKey: "AIzaSyDsK01Ma-bYGxsBE8RsSOUNm_9fs_ZOu-M",
  authDomain: "gen-lang-client-0537993898.firebaseapp.com",
  projectId: "gen-lang-client-0537993898",
  storageBucket: "gen-lang-client-0537993898.firebasestorage.app",
  messagingSenderId: "564809276836",
  appId: "1:564809276836:web:16f240f067aaae4e54f531"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: payload.notification.image || '/logo.svg',
    data: payload.data
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
